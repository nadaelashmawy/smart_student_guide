import json

class KnowledgeBase:
    def __init__(self):
        self.courses = []
        self.rules = {}

    def load(self, courses, rules_path="data/rules.json"):
        self.courses = courses
        if isinstance(rules_path, dict):
            self.rules = rules_path
        else:
            try:
                with open(rules_path, "r", encoding="utf-8") as file:
                    self.rules = json.load(file)
            except FileNotFoundError:
                raise FileNotFoundError(f"Rules file not found: {rules_path}")

    def get_max_allowed_hours(self, cgpa, is_freshman=False):
        if is_freshman: return 18
        limits = self.rules.get("gpa_limits", [])
        for rule in sorted(limits, key=lambda item: item["min_gpa"], reverse=True):
            if cgpa >= rule["min_gpa"]: return rule["max_hours"]
        return 12

    def determine_student_level(self, completed_hours):
        levels = self.rules.get("academic_levels", [])
        for rule in levels:
            if completed_hours < rule["max_hours_completed"]: return rule["level"]
        if levels: return levels[-1]["level"]
        return 1

    def check_exam_eligibility(self, attendance_percentage):
        min_attendance = self.rules.get("attendance_and_exams", {}).get("min_attendance_percentage", 75)
        if attendance_percentage < min_attendance:
            return f"Not eligible for the final exam: attendance is below {min_attendance}%."
        return "Eligible for final exam."

    def is_summer_training_eligible(self, completed_hours):
        min_hours = self.rules.get("special_courses_rules", {}).get("summer_training", {}).get("min_completed_hours", 72)
        return completed_hours >= min_hours

    def _get_prerequisites(self, course):
        prerequisites = course.get("prerequisites") or ""
        if not isinstance(prerequisites, str): return []
        prerequisites = prerequisites.strip()
        if not prerequisites or prerequisites.lower() == "none": return []
        return [item.strip() for item in prerequisites.replace(",", ";").split(";") if item.strip()]

    def _get_graduation_project_codes(self):
        project_rules = self.rules.get("special_courses_rules", {}).get("graduation_project", {})
        return project_rules.get("course_codes", ["GP411"])

    @staticmethod
    def _offered_in(course, semester):
        """True if the course runs in the given semester (1 or 2). No semester filter, or a
        course whose semester is not recorded, counts as offered."""
        if semester in (None, "", 0):
            return True
        course_semester = str(course.get("semester") or "").strip()
        if not course_semester:
            return True
        return course_semester == str(semester).strip()

    def eligible_courses(self, completed_courses, student_passed_hours=0, semester=None):
        """Courses the student can register for. If `semester` (1 or 2) is given, only courses
        offered in that semester are returned."""
        eligible = []
        project_rules = self.rules.get("special_courses_rules", {}).get("graduation_project", {})
        min_project_hours = project_rules.get("min_completed_hours", 100)
        project_codes = self._get_graduation_project_codes()
        for course in self.courses:
            code = course.get("code")
            if not code or code in completed_courses: continue
            if code in project_codes and student_passed_hours < min_project_hours: continue
            if not self._offered_in(course, semester): continue
            prerequisites = self._get_prerequisites(course)
            if all(prerequisite in completed_courses for prerequisite in prerequisites):
                eligible.append(code)
        return eligible

    def why_not(self, completed_courses, course_code, student_passed_hours=0, semester=None):
        if course_code in completed_courses:
            return f"You have already passed {course_code}."
        target_course = next((course for course in self.courses if course.get("code") == course_code), None)
        if target_course is None:
            return f"Course {course_code} does not exist in the curriculum."
        reasons = []
        project_rules = self.rules.get("special_courses_rules", {}).get("graduation_project", {})
        min_project_hours = project_rules.get("min_completed_hours", 100)
        project_codes = self._get_graduation_project_codes()
        if course_code in project_codes and student_passed_hours < min_project_hours:
            reasons.append(f"Graduation project requires at least {min_project_hours} completed hours. Current hours: {student_passed_hours}.")
        if not self._offered_in(target_course, semester):
            reasons.append(f"This course is offered in semester {str(target_course.get('semester')).strip()}, not in semester {semester}.")
        prerequisites = self._get_prerequisites(target_course)
        missing = [prerequisite for prerequisite in prerequisites if prerequisite not in completed_courses]
        if missing:
            reasons.append("Missing prerequisites: " + ", ".join(missing) + ".")
        if reasons:
            return f"Cannot register {course_code}: " + " ".join(reasons)
        return f"Course {course_code} is available for registration."
