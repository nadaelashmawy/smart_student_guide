"""TechNova design system for the Smart Student Guide Tkinter UIs.

Shared palette, brand logo (TN), animated banner, sidebar navigation, cards and
animation helpers.  Everything animates with root.after() so the UI never
freezes (no time.sleep).  All helpers stop quietly if a widget is destroyed
while an animation is running.
"""
import math
import os
import tkinter as tk
from tkinter import font as tkfont

FPS_MS = 16  # ~60 FPS

# ---------------------------------------------------------------- palette
NAVY = "#0A0E2A"
NAVY2 = "#161C52"
SIDEBAR = "#0E1330"
SIDEBAR_HOVER = "#1B2257"
SIDEBAR_ACTIVE = "#272D86"
VIOLET = "#6C5CE7"
CYAN = "#00C2FF"
PINK = "#FF5C8A"
ORANGE = "#FFA94D"
GREEN = "#22C58B"
APP_BG = "#F3F5FB"
CARD_LINE = "#E3E6F3"
INK = "#1B1F3B"
MUTED = "#6B7194"


# ---------------------------------------------------------------- colours
def _hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def lerp_color(c1, c2, t):
    a, b = _hex_to_rgb(c1), _hex_to_rgb(c2)
    return _rgb_to_hex([a[i] + (b[i] - a[i]) * t for i in range(3)])


def darker(color, amount=0.12):
    return lerp_color(color, "#000000", amount)


def ease_out(t):
    """Cubic ease-out: fast start, soft landing."""
    return 1 - (1 - t) ** 3


def linear(t):
    return t


def _alive(w):
    try:
        return bool(w.winfo_exists())
    except tk.TclError:
        return False


# ---------------------------------------------------------------- tween
def tween(widget, duration_ms, on_step, on_done=None, easing=ease_out):
    """Call on_step(progress 0..1) repeatedly over duration_ms."""
    steps = max(1, duration_ms // FPS_MS)
    state = {"i": 0}

    def tick():
        if not _alive(widget):
            return
        state["i"] += 1
        t = min(1.0, state["i"] / steps)
        try:
            on_step(easing(t))
        except tk.TclError:
            return
        if t < 1.0:
            widget.after(FPS_MS, tick)
        elif on_done:
            on_done()

    tick()


def animate_color(widget, option, start, end, duration_ms=140):
    """Smoothly fade a widget colour option (bg / fg / ...) from start to end."""
    token = object()
    widget._anim_tokens = getattr(widget, "_anim_tokens", {})
    widget._anim_tokens[option] = token

    def step(t):
        if widget._anim_tokens.get(option) is not token:
            return  # a newer animation took over
        try:
            widget.configure(**{option: lerp_color(start, end, t)})
        except tk.TclError:
            pass

    tween(widget, duration_ms, step)


# ---------------------------------------------------------------- canvas drawing helpers
def rr_points(x0, y0, x1, y1, r):
    r = max(0, min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    return [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
            x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]


def round_rect(c, x0, y0, x1, y1, r=18, **kw):
    return c.create_polygon(rr_points(x0, y0, x1, y1, r), smooth=True, **kw)


def draw_vgradient(c, w, h, c1, c2, tags=(), step=4):
    for y in range(0, h, step):
        c.create_rectangle(0, y, w, y + step, fill=lerp_color(c1, c2, y / max(1, h - 1)),
                           width=0, tags=tags)


def spaced(text):
    """'SMART GUIDE' -> 'S M A R T   G U I D E' (cheap letter-spacing)."""
    return "   ".join(" ".join(word) for word in text.split())


def draw_logo(c, cx, cy, size, tags=()):
    """TechNova 'TN' badge: rounded square + white T + cyan N."""
    h = size / 2
    round_rect(c, cx - h, cy - h + 4, cx + h, cy + h + 4, r=size * 0.26,
               fill=lerp_color(NAVY, "#000000", 0.25), outline="", tags=tags)       # soft shadow
    round_rect(c, cx - h, cy - h, cx + h, cy + h, r=size * 0.26,
               fill=VIOLET, outline=lerp_color(VIOLET, "#FFFFFF", 0.35), width=1, tags=tags)
    round_rect(c, cx - h + 3, cy - h + 3, cx + h - 3, cy - 1, r=size * 0.22,
               fill=lerp_color(VIOLET, "#FFFFFF", 0.16), outline="", tags=tags)     # glossy top
    f = tkfont.Font(family="Segoe UI", size=-int(size * 0.42), weight="bold")
    wt, wn = f.measure("T"), f.measure("N")
    x = cx - (wt + wn) / 2
    c.create_text(x, cy, text="T", anchor="w", font=f, fill="#FFFFFF", tags=tags)
    c.create_text(x + wt, cy, text="N", anchor="w", font=f, fill="#7DE3FF", tags=tags)


_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_LOGO_CACHE = {}


def load_logo(size, master=None):
    """Pre-sized TechNova PNG (assets/technova_logo_<size>.png). None if the file is missing."""
    img = _LOGO_CACHE.get(size)
    if img is None:
        path = os.path.join(_ASSETS, f"technova_logo_{size}.png")
        if not os.path.exists(path):
            return None
        try:
            img = tk.PhotoImage(master=master, file=path)
        except tk.TclError:
            return None
        _LOGO_CACHE[size] = img
    return img


def draw_logo_image(c, cx, cy, size, tags=()):
    """Draw the real TechNova logo image (falls back to the old TN badge if the PNG is missing)."""
    img = load_logo(size, c)
    if img is None:
        draw_logo(c, cx, cy, size, tags)
        return False
    c._logo_refs = getattr(c, "_logo_refs", []) + [img]       # keep a reference alive
    h = size / 2
    c.create_rectangle(cx - h - 1, cy - h - 1, cx + h + 1, cy + h + 1,
                       outline=lerp_color(NAVY, CYAN, 0.55), width=1, tags=tags)
    c.create_image(cx, cy, image=img, tags=tags)
    return True


def pulse_ring(c, cx, cy, size, color, bg, period_ms=2600, rings=2, paused=None):
    """Expanding, fading rings around the logo (loops until the canvas dies).

    `paused` is an optional callable; while it returns True the animation idles (no redraws)."""
    items = [c.create_polygon(rr_points(cx, cy, cx, cy, 0), smooth=True, fill="", outline=bg, width=2,
                              tags="pulse") for _ in range(rings)]
    state = {"t": 0.0}

    def tick():
        if not _alive(c):
            return
        if paused is not None and paused():
            c.after(120, tick)
            return
        state["t"] += 33.0
        for i, it in enumerate(items):
            p = ((state["t"] / period_ms) + i / rings) % 1.0
            half = size / 2 + 4 + p * size * 0.42
            try:
                c.coords(it, *rr_points(cx - half, cy - half, cx + half, cy + half, size * 0.26 + p * 16))
                c.itemconfigure(it, outline=lerp_color(color, bg, min(1.0, p * 1.1)),
                                width=max(1, int(3 * (1 - p)) + 1))
            except tk.TclError:
                return
        c.after(33, tick)

    tick()
    return items


class LogoBadge(tk.Canvas):
    """Small static TechNova logo for sidebars (uses assets/technova_logo_<size>.png)."""

    def __init__(self, parent, size=52, bg=SIDEBAR):
        pad = 4
        super().__init__(parent, width=size + pad * 2, height=size + pad * 2 + 4, bg=bg,
                         highlightthickness=0, bd=0)
        draw_logo_image(self, size / 2 + pad, size / 2 + pad, size)


def brand_block(parent, bg=SIDEBAR):
    """Sidebar header: TN badge + 'TechNova' + product name."""
    f = tk.Frame(parent, bg=bg)
    LogoBadge(f, 52, bg).pack(side="left", padx=(0, 10))
    t = tk.Frame(f, bg=bg)
    t.pack(side="left")
    tk.Label(t, text="TechNova", bg=bg, fg="#FFFFFF", font=("Segoe UI", 15, "bold")).pack(anchor="w")
    tk.Label(t, text="SMART STUDENT GUIDE", bg=bg, fg="#7F88C9", font=("Segoe UI", 7, "bold")).pack(anchor="w")
    return f


# ---------------------------------------------------------------- buttons
def hover_button(btn, base_bg, hover_bg, base_fg=None, hover_fg=None, duration_ms=140):
    """Smooth hover colour fade + hand cursor. Returns the button."""
    btn.configure(relief="flat", bd=0, highlightthickness=0, cursor="hand2", activebackground=hover_bg,
                  activeforeground=hover_fg or base_fg or btn.cget("fg"))
    btn._base_bg = base_bg

    def enter(_):
        animate_color(btn, "bg", btn._base_bg, hover_bg, duration_ms)
        if base_fg and hover_fg:
            animate_color(btn, "fg", base_fg, hover_fg, duration_ms)

    def leave(_):
        animate_color(btn, "bg", hover_bg, btn._base_bg, duration_ms)
        if base_fg and hover_fg:
            animate_color(btn, "fg", hover_fg, base_fg, duration_ms)

    btn.bind("<Enter>", enter, add="+")
    btn.bind("<Leave>", leave, add="+")
    return btn


def action_button(parent, text, color, command, fg="#FFFFFF", padx=18, pady=10, font=("Segoe UI", 10, "bold")):
    b = tk.Button(parent, text=text, bg=color, fg=fg, font=font, padx=padx, pady=pady, command=command)
    return hover_button(b, color, darker(color))


def soft_button(parent, text, command, bg="#F0EFFD", fg=VIOLET, hover="#E1DFFF", padx=12, pady=8):
    b = tk.Button(parent, text=text, bg=bg, fg=fg, font=("Segoe UI", 10, "bold"), padx=padx, pady=pady,
                  command=command)
    return hover_button(b, bg, hover)


def auto_hover(container):
    """Give every plain tk.Button inside `container` a smooth hover fade."""
    stack = list(container.winfo_children())
    while stack:
        w = stack.pop()
        stack.extend(w.winfo_children())
        if isinstance(w, tk.Button) and not hasattr(w, "_base_bg"):
            try:
                bg = w.cget("bg")
                hover_button(w, bg, darker(bg, 0.09))
                w.configure(font=("Segoe UI", 10, "bold"))
            except tk.TclError:
                pass


# ---------------------------------------------------------------- sidebar navigation
class NavButton:
    """Dark sidebar item: animated hover, animated active state + accent strip."""

    def __init__(self, parent, text, command, nav_bg=SIDEBAR, active_bg=SIDEBAR_ACTIVE,
                 hover_bg=SIDEBAR_HOVER, fg="#A8AFDB", active_fg="#FFFFFF", accent=CYAN):
        self.nav_bg, self.active_bg, self.hover_bg = nav_bg, active_bg, hover_bg
        self.fg, self.active_fg, self.accent = fg, active_fg, accent
        self.active = False
        self.frame = tk.Frame(parent, bg=nav_bg)
        self.strip = tk.Frame(self.frame, bg=nav_bg, width=4)
        self.strip.pack(side="left", fill="y")
        self.widget = tk.Button(self.frame, text=text, anchor="w", relief="flat", bd=0, highlightthickness=0,
                                bg=nav_bg, fg=fg,
                                activebackground=active_bg, activeforeground=active_fg,
                                font=("Segoe UI", 10), padx=14, pady=11, cursor="hand2", command=command)
        self.widget.pack(side="left", fill="x", expand=True)
        self.widget.bind("<Enter>", self._enter)
        self.widget.bind("<Leave>", self._leave)

    def pack(self, **kw):
        self.frame.pack(**kw)

    def _enter(self, _):
        if not self.active:
            animate_color(self.widget, "bg", self.nav_bg, self.hover_bg, 120)
            animate_color(self.widget, "fg", self.fg, "#FFFFFF", 120)

    def _leave(self, _):
        if not self.active:
            animate_color(self.widget, "bg", self.hover_bg, self.nav_bg, 120)
            animate_color(self.widget, "fg", "#FFFFFF", self.fg, 120)

    def set_active(self, on):
        if on == self.active:
            return
        self.active = on
        w = self.widget
        if on:
            animate_color(w, "bg", w.cget("bg"), self.active_bg, 220)
            animate_color(w, "fg", w.cget("fg"), self.active_fg, 220)
            animate_color(self.strip, "bg", self.strip.cget("bg"), self.accent, 220)
            w.configure(font=("Segoe UI", 10, "bold"))
        else:
            animate_color(w, "bg", w.cget("bg"), self.nav_bg, 220)
            animate_color(w, "fg", w.cget("fg"), self.fg, 220)
            animate_color(self.strip, "bg", self.strip.cget("bg"), self.nav_bg, 220)
            w.configure(font=("Segoe UI", 10))


# ---------------------------------------------------------------- banner header
class Banner(tk.Canvas):
    """Gradient page header: title, subtitle, right-side tag chip, loading sweep."""

    def __init__(self, parent, title="", subtitle="", tag="", c1=VIOLET, c2=CYAN, height=88):
        super().__init__(parent, height=height, highlightthickness=0, bd=0, bg=c1)
        self.c1, self.c2, self.h = c1, c2, height
        self._title, self._sub, self._tag = title, subtitle, tag
        self._last_w, self._redraw_job = 0, None
        self.bind("<Configure>", self._on_configure)

    def _on_configure(self, e):
        if e.width == self._last_w:          # moving the window never needs a redraw
            return
        if self._redraw_job is not None:
            try:
                self.after_cancel(self._redraw_job)
            except tk.TclError:
                pass
        self._redraw_job = self.after_idle(self._draw)

    def _grad(self, x, w):
        return lerp_color(self.c1, self.c2, x / max(1, w))

    def _draw(self, _=None):
        self._redraw_job = None
        w = max(self.winfo_width(), 2)
        self._last_w = w
        self.delete("all")
        for x in range(0, w, 4):
            self.create_rectangle(x, 0, x + 4, self.h, fill=self._grad(x, w), width=0)
        for cx, cy, r, a in ((w - 70, 6, 95, 0.10), (w - 210, self.h + 20, 70, 0.08), (w * 0.52, -30, 80, 0.07)):
            col = lerp_color(self._grad(cx, w), "#FFFFFF", a)
            self.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="")
        self.create_text(30, self.h / 2 - (10 if self._sub else 0), text=self._title, anchor="w",
                         font=("Segoe UI", 21, "bold"), fill="#FFFFFF", tags="title")
        self.create_text(31, self.h / 2 + 18, text=self._sub, anchor="w", font=("Segoe UI", 10),
                         fill=lerp_color(self._grad(60, w), "#FFFFFF", 0.85), tags="sub")
        if self._tag:
            t = self.create_text(w - 36, self.h / 2, text=self._tag, anchor="e",
                                 font=("Segoe UI", 9, "bold"), fill="#FFFFFF", tags="chip")
            bb = self.bbox(t)
            if bb:
                pill = round_rect(self, bb[0] - 16, bb[1] - 8, bb[2] + 16, bb[3] + 8, r=16,
                                  fill=lerp_color(self._grad(w - 90, w), "#FFFFFF", 0.22), outline="")
                self.tag_lower(pill, t)

    def set_title(self, text):
        if text == self._title:
            return
        self._title = text
        self._fade_item("title", text)

    def set_sub(self, text):
        if text == self._sub:
            return
        self._sub = text
        self._fade_item("sub", text)

    def _fade_item(self, tag, text):
        try:
            self.itemconfigure(tag, text=text)
        except tk.TclError:
            return
        w = max(self.winfo_width(), 2)
        final = "#FFFFFF" if tag == "title" else lerp_color(self._grad(60, w), "#FFFFFF", 0.85)
        start = self._grad(60, w)

        def step(t):
            self.itemconfigure(tag, fill=lerp_color(start, final, t))

        tween(self, 320, step)

    def flash(self):
        """Light sweep along the bottom edge - used on every page change."""
        w = max(self.winfo_width(), 2)
        bar = self.create_rectangle(0, self.h - 4, 0, self.h, fill="#FFFFFF", width=0, tags="sweep")

        def step(t):
            x = -w * 0.3 + (w * 1.3) * t
            self.coords(bar, max(0, x), self.h - 4, min(w, x + w * 0.3), self.h)

        def done():
            try:
                self.delete(bar)
            except tk.TclError:
                pass

        tween(self, 650, step, done, easing=linear)


# ---------------------------------------------------------------- numbers
def count_up(label, target, duration_ms=800, fmt="{:g}"):
    """Animate a Label's text from 0 up to `target` (int/float)."""
    try:
        target = float(target)
    except (TypeError, ValueError):
        label.configure(text=str(target))
        return
    is_int = float(target).is_integer()

    def step(t):
        v = target * t
        label.configure(text=str(int(round(v))) if is_int else fmt.format(v))

    tween(label, duration_ms, step)


# ---------------------------------------------------------------- page transitions
def _first_child(container, skip):
    for w in container.winfo_children():
        if w is not skip:
            return w
    return None


def slide_fade_in(container, bg, text_widgets=(), distance=28, duration_ms=360):
    """Page-enter animation: content slides up into place and text fades in."""
    spacer = tk.Frame(container, bg=bg, height=distance)
    spacer.pack(side="top", fill="x", before=_first_child(container, spacer))
    finals = []
    for w in text_widgets:
        try:
            finals.append((w, w.cget("fg")))
            w.configure(fg=bg)
        except tk.TclError:
            pass

    def step(t):
        spacer.configure(height=max(0, int(distance * (1 - t))))
        for w, fg in finals:
            try:
                w.configure(fg=lerp_color(bg, fg, t))
            except tk.TclError:
                pass

    def done():
        try:
            spacer.destroy()
        except tk.TclError:
            pass

    tween(container, duration_ms, step, done)


def finish_page(body, bg, banner=None):
    """Call after a page is built: hover on buttons + slide/fade-in (+ banner sweep)."""
    auto_hover(body)
    labels = [w for w in body.winfo_children() if isinstance(w, tk.Label)]
    slide_fade_in(body, bg, labels)
    if banner is not None:
        banner.flash()


# ---------------------------------------------------------------- cards
def accent_strip(frame, color, height=4):
    """Coloured bar glued to the top edge of a card (ignores the card padding)."""
    strip = tk.Frame(frame, bg=color, height=height)
    try:  # place() is relative to the padded area, so reach back out to the card edge
        ix = frame.winfo_pixels(frame.cget("padx")) + int(float(frame.cget("highlightthickness")))
        iy = frame.winfo_pixels(frame.cget("pady")) + int(float(frame.cget("highlightthickness")))
    except (tk.TclError, ValueError):
        ix = iy = 0
    strip.place(x=-ix, y=-iy, relwidth=1, width=2 * ix)
    return strip


def card_hover(frame, base_border=CARD_LINE, hover_border=VIOLET):
    """Border colour animates when the mouse is over the card (or any child)."""
    state = {"over": False}

    def enter(_):
        if not state["over"]:
            state["over"] = True
            animate_color(frame, "highlightbackground", base_border, hover_border, 160)

    def leave(_):
        try:
            x, y = frame.winfo_pointerxy()
            w = frame.winfo_containing(x, y)
        except (tk.TclError, KeyError):
            w = None
        inside = False
        while w is not None:
            if w is frame:
                inside = True
                break
            w = getattr(w, "master", None)
        if not inside and state["over"]:
            state["over"] = False
            animate_color(frame, "highlightbackground", hover_border, base_border, 160)

    frame.bind("<Enter>", enter, add="+")
    frame.bind("<Leave>", leave, add="+")
    stack = list(frame.winfo_children())
    while stack:
        child = stack.pop()
        stack.extend(child.winfo_children())
        child.bind("<Enter>", enter, add="+")
        child.bind("<Leave>", leave, add="+")


def stat_card(parent, title, value, sub, color, white="#FFFFFF"):
    """Dashboard KPI card: coloured top bar, animated number, tinted icon dot."""
    f = tk.Frame(parent, bg=white, highlightbackground=CARD_LINE, highlightthickness=1, padx=18, pady=16)
    accent_strip(f, color)
    top = tk.Frame(f, bg=white)
    top.pack(fill="x", pady=(4, 0))
    tk.Label(top, text=title, bg=white, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(side="left", anchor="n")
    dot = tk.Canvas(top, width=30, height=30, bg=white, highlightthickness=0)
    dot.pack(side="right")
    dot.create_oval(1, 1, 29, 29, fill=lerp_color(color, white, 0.85), outline="")
    dot.create_oval(9, 9, 21, 21, fill=color, outline="")
    vl = tk.Label(f, text="0", bg=white, fg=color, font=("Segoe UI", 26, "bold"))
    vl.pack(anchor="w", pady=(6, 0))
    tk.Label(f, text=sub, bg=white, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")
    count_up(vl, value)
    card_hover(f, CARD_LINE, color)
    return f


# ---------------------------------------------------------------- window / ttk
def fade_in_window(root, duration_ms=380):
    """Window fades in on start (silently skipped where -alpha is unsupported)."""
    try:
        root.attributes("-alpha", 0.0)
    except tk.TclError:
        return

    def step(t):
        try:
            root.attributes("-alpha", t)
        except tk.TclError:
            pass

    tween(root, duration_ms, step)


def center_window(win, w, h):
    win.update_idletasks()
    x = max(0, (win.winfo_screenwidth() - w) // 2)
    y = max(0, (win.winfo_screenheight() - h) // 2 - 20)
    win.geometry(f"{w}x{h}+{x}+{y}")


def style_ttk(st, white=None, ink=INK, line=CARD_LINE, accent=VIOLET, bg=APP_BG, muted=MUTED):
    """Modern ttk look: focus ring on inputs, clean tables, slim scrollbars."""
    white = white or "#FFFFFF"
    st.configure("TEntry", padding=7, fieldbackground=white, bordercolor=line,
                 lightcolor=line, darkcolor=line, foreground=ink)
    st.map("TEntry", bordercolor=[("focus", accent)], lightcolor=[("focus", accent)],
           darkcolor=[("focus", accent)])
    st.configure("TCombobox", padding=8, fieldbackground=white, bordercolor=line,
                 lightcolor=line, darkcolor=line, arrowcolor=muted, foreground=ink)
    st.map("TCombobox", bordercolor=[("focus", accent)], lightcolor=[("focus", accent)],
           darkcolor=[("focus", accent)], fieldbackground=[("readonly", white)])
    st.configure("Treeview", rowheight=32, font=("Segoe UI", 10), background=white,
                 fieldbackground=white, foreground=ink, borderwidth=0)
    st.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#EEF0FA",
                 foreground=ink, padding=10, relief="flat", borderwidth=0)
    st.map("Treeview", background=[("selected", "#E4E0FF")], foreground=[("selected", ink)])
    st.map("Treeview.Heading", background=[("active", "#E1DFFF")])
    try:
        st.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    except tk.TclError:
        pass
    for orient in ("Vertical", "Horizontal"):
        st.configure(f"{orient}.TScrollbar", background="#CFD3EA", troughcolor=bg,
                     bordercolor=bg, lightcolor="#CFD3EA", darkcolor="#CFD3EA",
                     arrowcolor=muted, relief="flat")
        st.map(f"{orient}.TScrollbar", background=[("active", accent)])
