"""Modern dashboard-style Student UI for Smart Student Guide (Tkinter)."""
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import json
import re
import storage
import ui_kit as kit
import ir_engine
from kb_engine import KnowledgeBase

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
COURSES = DATA / "courses.csv"
STUDENTS = DATA / "students.json"
FAQ = DATA / "faqs.json"
RULES = DATA / "rules.json"
DOCS = DATA / "documents"
BG="#F3F5FB"; NAV="#F0F0F8"; WHITE="#FFFFFF"; INK="#1B1F3B"; MUTED="#6B7194"
PURPLE="#6C5CE7"; TEAL="#00B8A9"; LINE="#E3E6F3"; PALE="#E9F8F5"

def read_courses():
    return storage.read_csv(str(COURSES))
def read_students():
    d=storage.read_json(str(STUDENTS)); return d if isinstance(d,dict) else {}
def read_faqs():
    d=storage.read_json(str(FAQ)); return d if isinstance(d,list) else (d.get("faqs",[]) if isinstance(d,dict) else [])

SEMESTER_CHOICES=["Semester 1 (Fall)","Semester 2 (Spring)","All semesters"]

DOC_FILTERS={"All":"","Regulations":"reg_","Courses":"course_","Staff":"staff_","Rooms":"room_"}

def read_records(filename):
    """Load a JSON data file as a list of dicts. Accepts a list, or a dict keyed by ID (R01, T01, ...)."""
    d=storage.read_json(str(DATA/filename),[])
    if isinstance(d,dict):
        return [dict(v,id=k) for k,v in d.items() if isinstance(v,dict)]
    if isinstance(d,list):
        return [x for x in d if isinstance(x,dict)]
    return []
def _norm_name(s):
    """Normalise a name for comparison: case, extra spaces, Arabic diacritics/alef forms."""
    s=str(s or "").lower()
    s=re.sub(r"[\u064B-\u0652\u0640]","",s)
    s=re.sub(r"[أإآ]","ا",s)
    return " ".join(s.split())

class StudentUI:
    def __init__(self, root=None):
        self.root=root or tk.Tk()
        self.root.title("Smart Student Guide | Student Dashboard")
        self.root.geometry("1180x760"); self.root.minsize(980,650); self.root.configure(bg=BG)
        self.students=read_students(); self.courses=read_courses(); self.current_student=None
        self.kb=KnowledgeBase()
        try: self.kb.load(self.courses,str(RULES))
        except Exception: pass
        self._styles(); self._layout(); self.show_page("Dashboard"); self.refresh_courses()
        if isinstance(self.root,tk.Tk): kit.fade_in_window(self.root)   # -alpha on a Toplevel makes dragging laggy on Windows
    def _styles(self):
        st=ttk.Style()
        try: st.theme_use("clam")
        except tk.TclError: pass
        kit.style_ttk(st,WHITE,INK,LINE,PURPLE,BG,MUTED)
    def _layout(self):
        shell=tk.Frame(self.root,bg=BG); shell.pack(fill="both",expand=True)
        side=tk.Frame(shell,bg=kit.SIDEBAR,width=240); side.pack(side="left",fill="y"); side.pack_propagate(False)
        kit.brand_block(side).pack(anchor="w",padx=20,pady=(26,28))
        tk.Label(side,text="MENU",bg=kit.SIDEBAR,fg="#5F679F",font=("Segoe UI",8,"bold")).pack(anchor="w",padx=24,pady=(0,8))
        self.nav={}
        for name,icon in [("Dashboard","\u2302"),("Find Courses","\u25A6"),("Regulations","\u25A4"),("Registration Check","\u2713"),("Staff Members","\u263A"),("Rooms & Labs","\u25A3"),("FAQs","?")]:
            b=kit.NavButton(side,f"  {icon}    {name}",lambda n=name:self.show_page(n))
            b.pack(fill="x",padx=(0,14),pady=2); self.nav[name]=b
        tk.Label(side,text="\u00a9 2026 TechNova",bg=kit.SIDEBAR,fg="#5F679F",font=("Segoe UI",8)).pack(side="bottom",anchor="w",padx=24,pady=(0,18))
        tk.Label(side,text="Find answers. Plan better.",bg=kit.SIDEBAR,fg="#8A92C4",font=("Segoe UI",8)).pack(side="bottom",anchor="w",padx=24,pady=(0,4))
        tk.Label(side,text="ACADEMIC ASSISTANT",bg=kit.SIDEBAR,fg="#8A92C4",font=("Segoe UI",8,"bold")).pack(side="bottom",anchor="w",padx=24)
        tk.Frame(side,bg="#1F2760",height=1).pack(side="bottom",fill="x",padx=20,pady=(0,12))
        main=tk.Frame(shell,bg=BG); main.pack(side="left",fill="both",expand=True)
        self.hello=kit.Banner(main,"Hi, Student","Your academic information, all in one place","STUDENT PORTAL","#6C5CE7","#0095DB")
        self.hello.pack(fill="x")
        self.body=tk.Frame(main,bg=BG); self.body.pack(fill="both",expand=True,padx=30,pady=(20,14))
    def show_page(self,name):
        for n,b in self.nav.items():
            b.set_active(n==name)
        for w in self.body.winfo_children(): w.destroy()
        titles={"Dashboard":"Your academic overview","Find Courses":"Find a course","Regulations":"University regulations","Registration Check":"Registration eligibility","FAQs":"Frequently asked questions","Staff Members":"Faculty Staff Members","Rooms & Labs":"Campus Rooms & Labs"}
        self.hello.set_sub(titles.get(name,name))
        
        if name=="Dashboard": self._dashboard()
        elif name=="Find Courses": self._courses_page()
        elif name=="Regulations": self._regulations_page()
        elif name=="Registration Check": self._eligibility_page()
        elif name=="FAQs": self._faq_page()
        elif name=="Staff Members": self._staff_page()
        elif name=="Rooms & Labs": self._rooms_page()
        kit.finish_page(self.body,BG,self.hello)   # button hover + slide/fade-in

    def card(self,parent,title,value,sub,color):
        return kit.stat_card(parent,title,value,sub,color)

    # === FIX 3: Data Entry Form for Student ===
    def _dashboard(self):
        row=tk.Frame(self.body,bg=BG); row.pack(fill="x",pady=(0,15))
        for title,val,sub,col in [("Available courses",str(len(self.courses)),"Courses in catalog",PURPLE),("Students",str(len(self.students)),"Student records",TEAL),("FAQs",str(len(read_faqs())),"Quick answers","#F59E0B")]:
            self.card(row,title,val,sub,col).pack(side="left",fill="x",expand=True,padx=(0,12))
        
        prof=tk.Frame(self.body,bg=WHITE,highlightbackground=LINE,highlightthickness=1,padx=18,pady=12)
        prof.pack(fill="x",pady=(0,12))
        
        tk.Label(prof,text="Register / Update Your Academic Profile",bg=WHITE,fg=INK,font=("Segoe UI",12,"bold")).grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,12))
        
        tk.Label(prof,text="Student Name:",bg=WHITE,fg=MUTED).grid(row=1,column=0,sticky="w")
        self.sname_reg = ttk.Entry(prof, width=40)
        self.sname_reg.grid(row=1,column=1,sticky="w",pady=4,padx=10)

        tk.Label(prof,text="Student ID (Code):",bg=WHITE,fg=MUTED).grid(row=2,column=0,sticky="w")
        self.sid_reg = ttk.Entry(prof, width=40)
        self.sid_reg.grid(row=2,column=1,sticky="w",pady=4,padx=10)

        tk.Label(prof,text="CGPA:",bg=WHITE,fg=MUTED).grid(row=3,column=0,sticky="w")
        self.sgpa_reg = ttk.Entry(prof, width=40)
        self.sgpa_reg.grid(row=3,column=1,sticky="w",pady=4,padx=10)

        tk.Label(prof,text="Completed Hours:",bg=WHITE,fg=MUTED).grid(row=4,column=0,sticky="w")
        self.shours_reg = ttk.Entry(prof, width=40)
        self.shours_reg.grid(row=4,column=1,sticky="w",pady=4,padx=10)

        tk.Label(prof,text="Passed Courses (e.g. BC111, MA112):",bg=WHITE,fg=MUTED).grid(row=5,column=0,sticky="w")
        self.scourses_reg = ttk.Entry(prof, width=60)
        self.scourses_reg.grid(row=5,column=1,sticky="w",pady=4,padx=10)

        tk.Button(prof,text="Save Profile & Start Advising",bg=PURPLE,fg=WHITE,relief="flat",padx=14,pady=8,command=self._save_student_profile).grid(row=6,column=0,columnspan=2,pady=(15,5),sticky="w")

        # Pre-fill if student is already logged in
        if self.current_student and self.current_student in self.students:
            st = self.students[self.current_student]
            self.sid_reg.insert(0, self.current_student)
            self.sname_reg.insert(0, st.get("name",""))
            self.sgpa_reg.insert(0, str(st.get("cgpa","")))
            self.shours_reg.insert(0, f"{self._student_hours(st):g}")
            self.scourses_reg.insert(0, ", ".join(st.get("completed",[])))

        kit.accent_strip(prof,PURPLE)
        quick=tk.Frame(self.body,bg=BG); quick.pack(fill="both",expand=True)
        for title,desc,btn,page,color in [
            ("Registration check","Check prerequisites and eligibility.","Check eligibility","Registration Check",TEAL),
            ("Staff & Rooms","View faculty staff and campus rooms.","View details","Staff Members","#F59E0B")]:
            f=tk.Frame(quick,bg=WHITE,highlightbackground=LINE,highlightthickness=1,padx=16,pady=14)
            f.pack(side="left",fill="both",expand=True,padx=(0,10),pady=4)
            tk.Label(f,text="●",bg=WHITE,fg=color,font=("Segoe UI",18)).pack(anchor="w")
            tk.Label(f,text=title,bg=WHITE,fg=INK,font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(7,4))
            tk.Label(f,text=desc,bg=WHITE,fg=MUTED,wraplength=160,justify="left").pack(anchor="w")
            tk.Button(f,text=btn,bg="#F0EFFD",fg=PURPLE,relief="flat",padx=10,pady=7,command=lambda p=page:self.show_page(p)).pack(anchor="w",pady=(12,0))
            kit.accent_strip(f,color); kit.card_hover(f,LINE,color)

    def _save_student_profile(self):
        sid = self.sid_reg.get().strip()
        name = self.sname_reg.get().strip()
        if not sid:
            messagebox.showwarning("Missing ID", "Student ID is required.")
            return
        if not name:
            messagebox.showwarning("Missing name", "Student name is required (it is used together with the ID for the registration check).")
            return
        # Do not overwrite another student's record
        existing = next((k for k in self.students if str(k).strip().upper() == sid.upper()), None)
        if existing is not None:
            sid = existing
            if _norm_name(self.students[sid].get("name", "")) != _norm_name(name):
                messagebox.showerror("ID already in use", f"Student ID {sid} already belongs to a different student name.\nPlease check your ID and name.")
                return
        try:
            gpa = float(self.sgpa_reg.get().strip()) if self.sgpa_reg.get().strip() else 0.0
            hours_txt = self.shours_reg.get().strip()
            hours = float(hours_txt) if hours_txt else None
        except ValueError:
            messagebox.showerror("Invalid Input", "CGPA and Completed Hours must be numbers.")
            return
        if not 0.0 <= gpa <= 4.0:
            messagebox.showerror("Invalid CGPA", "CGPA must be between 0 and 4.")
            return
        if hours is not None and hours < 0:
            messagebox.showerror("Invalid hours", "Completed hours cannot be negative.")
            return

        courses_str = self.scourses_reg.get().strip()
        passed_courses = []
        for c in courses_str.split(","):
            c = c.strip().upper()
            if c and c not in passed_courses: passed_courses.append(c)
        known = {str(c.get("code", "")).strip().upper() for c in self.courses}
        unknown = [c for c in passed_courses if c not in known]
        if unknown:
            messagebox.showerror("Unknown course code", "These course codes are not in the catalog: " + ", ".join(unknown))
            return

        st_data = {"name": name, "cgpa": gpa, "completed": passed_courses}
        # Completed hours must agree with the credits of the passed courses (prevents unlocking
        # hour-based rules such as the 100-hour graduation-project condition by typing a big number).
        computed_hours = self._student_hours(st_data)
        if hours is not None and abs(hours - computed_hours) > 1e-9:
            messagebox.showerror(
                "Hours do not match",
                f"The passed courses you entered add up to {computed_hours:g} credit hours, "
                f"but you entered {hours:g}.\n\nCorrect the hours, add the missing passed courses, "
                "or leave the Completed Hours field empty to calculate it automatically.")
            return
        hours = computed_hours
        st_data["completed_hours"] = hours
        try:
            st_data["level"] = self.kb.determine_student_level(hours)
        except Exception:
            pass

        self.students[sid] = st_data
        storage.write_json(str(STUDENTS), self.students)

        self.current_student = sid
        self.hello.set_title(f"Hi, {name}")
        messagebox.showinfo("Profile Saved", "Your profile has been saved. You can now check your registration eligibility.")

    def refresh_courses(self, rows=None):
        rows=self.courses if rows is None else rows
        if hasattr(self,"course_tree") and self.course_tree.winfo_exists():
            self.course_tree.delete(*self.course_tree.get_children())
            for c in rows:self.course_tree.insert("", "end", values=(c.get("code",""),c.get("name",""),c.get("credits",""),c.get("prerequisites") or "None"))
    
    def _courses_page(self):
        bar=tk.Frame(self.body,bg=WHITE,padx=14,pady=12); bar.pack(fill="x",pady=(0,12))
        self.course_query=tk.StringVar()
        ent=ttk.Entry(bar,textvariable=self.course_query); ent.pack(side="left",fill="x",expand=True,padx=(0,10))
        tk.Button(bar,text="Search",bg=PURPLE,fg=WHITE,relief="flat",padx=18,pady=8,command=self.search_courses).pack(side="left",padx=4)
        tk.Button(bar,text="Show all",bg="#ECECF6",fg=INK,relief="flat",padx=15,pady=8,command=lambda:self.refresh_courses()).pack(side="left",padx=4)
        box=tk.Frame(self.body,bg=WHITE,padx=10,pady=10); box.pack(fill="both",expand=True)
        cols=("code","name","credits","prereq")
        self.course_tree=ttk.Treeview(box,columns=cols,show="headings")
        for c,t,w in [("code","Course code",130),("name","Course name",300),("credits","Credits",90),("prereq","Prerequisites",240)]:
            self.course_tree.heading(c,text=t,anchor="w"); self.course_tree.column(c,width=w,anchor="w")
        self.course_tree.pack(fill="both",expand=True)
        self.refresh_courses()
    def search_courses(self):
        q=self.course_query.get().strip().lower()
        rows=[c for c in self.courses if q in str(c.get("name","")).lower() or q in str(c.get("code","")).lower()] if q else self.courses
        self.refresh_courses(rows)
    def _regulations_page(self):
        bar=tk.Frame(self.body,bg=WHITE,padx=14,pady=12); bar.pack(fill="x")
        self.reg_query=tk.StringVar()
        ent=ttk.Entry(bar,textvariable=self.reg_query); ent.pack(side="left",fill="x",expand=True,padx=(0,10))
        ent.bind("<Return>",lambda e:self.search_regs())
        self.reg_filter=tk.StringVar(value="All")
        ttk.Combobox(bar,textvariable=self.reg_filter,values=list(DOC_FILTERS),state="readonly",width=13).pack(side="left",padx=(0,10))
        tk.Button(bar,text="Search",bg=TEAL,fg=WHITE,relief="flat",padx=14,pady=8,command=self.search_regs).pack(side="left")
        wrap=tk.Frame(self.body,bg=WHITE); wrap.pack(fill="both",expand=True,pady=12)
        sb=ttk.Scrollbar(wrap,orient="vertical"); sb.pack(side="right",fill="y")
        self.reg_results=tk.Text(wrap,wrap="word",font=("Segoe UI",10),bg=WHITE,fg=INK,relief="flat",padx=15,pady=15,yscrollcommand=sb.set)
        self.reg_results.pack(side="left",fill="both",expand=True); sb.configure(command=self.reg_results.yview)
        self.reg_results.tag_configure("title",font=("Segoe UI",11,"bold"),foreground=PURPLE)
        self.reg_results.tag_configure("score",foreground=MUTED,font=("Segoe UI",9))
        self.reg_results.insert("end","Ask in Arabic or English: attendance, الغياب, credit hours, who teaches machine learning, where is the networks lab...\nUse the filter to search only regulations, courses, staff or rooms.")
    def _doc_title(self,doc_id):
        prefix,_,rest=doc_id.partition("_")
        label={"reg":"Regulation","course":"Course","staff":"Staff","room":"Room"}.get(prefix,"Document")
        rest=rest.replace("_"," ").title()
        if prefix=="course": code,_,name=rest.partition(" "); rest=f"{code.upper()} - {name}"
        elif prefix in ("staff","room"): rest=rest.partition(" ")[2] or rest
        return f"{label}: {rest}"
    @staticmethod
    def _snippet(text,query):
        """Pick the Arabic or English part of a bilingual document to match the query language."""
        text=text.strip()
        ar_mark,en_mark="=== العربية ===","=== English ==="
        if ar_mark in text and en_mark in text:
            head=text.split("\n",1)[0]
            ar=text.split(ar_mark,1)[1].split(en_mark,1)[0].strip()
            en=text.split(en_mark,1)[1].strip()
            body=ar if re.search(r"[\u0600-\u06FF]",query) else en
            text=f"{head}\n{body}"
        text=text.replace("\r","")
        return text if len(text)<=1800 else text[:1800].rsplit(" ",1)[0]+" ..."
    def _ir_search(self,q,category="All"):
        engine_cls=getattr(ir_engine,"SearchEngine",None)
        if engine_cls is None:
            return getattr(ir_engine, "search_documents", lambda x,y: [])(q,DOCS)
        sig=tuple(sorted((p.name,p.stat().st_mtime_ns) for p in DOCS.glob("*.txt"))) if DOCS.exists() else ()
        if getattr(self,"_ir_sig",None)!=sig:
            self._docs=storage.load_documents(str(DOCS))
            self._engine=engine_cls(); self._engine.build_index(self._docs); self._ir_sig=sig
        prefix=DOC_FILTERS.get(category,"")
        out=[]
        for doc_id,score in self._engine.search(q,top_k=200):
            if prefix and not doc_id.startswith(prefix): continue
            out.append({"title":self._doc_title(doc_id),"score":round(score,4),"snippet":self._snippet(self._docs.get(doc_id,""),q)})
            if len(out)==5: break
        return out
    def search_regs(self):
        q=self.reg_query.get().strip()
        self.reg_results.delete("1.0","end")
        if not q:
            self.reg_results.insert("end","Please type a question or keyword first."); return
        results=self._ir_search(q,self.reg_filter.get())
        if not results:self.reg_results.insert("end","No matching result found. Try another keyword or change the filter.");return
        for r in results:
            self.reg_results.insert("end",f"{r.get('title','Document')}",("title",))
            self.reg_results.insert("end",f"   (relevance {r.get('score','')})\n","score")
            self.reg_results.insert("end",f"{r.get('snippet','')}\n\n")
        try: storage.log_query(self.current_student or "guest",q,f"{len(results)} documents")
        except Exception: pass

    # === Registration Check (verifies Student ID + Name together) ===
    def _eligibility_page(self):
        f=tk.Frame(self.body,bg=WHITE,padx=20,pady=18,highlightbackground=LINE,highlightthickness=1); f.pack(fill="x")
        tk.Label(f,text="Check your registration conditions",bg=WHITE,fg=INK,font=("Segoe UI",12,"bold")).grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,14))

        tk.Label(f,text="Student ID",bg=WHITE,fg=MUTED).grid(row=1,column=0,sticky="w")
        self.elig_sid=tk.StringVar(value=self.current_student or "")
        ttk.Entry(f,textvariable=self.elig_sid,width=24).grid(row=2,column=0,sticky="w",padx=(0,20))

        tk.Label(f,text="Student Name   (enter ID OR name — one is enough)",bg=WHITE,fg=MUTED).grid(row=1,column=1,sticky="w")
        cur_name = self.students.get(self.current_student,{}).get("name","") if self.current_student else ""
        self.elig_name=tk.StringVar(value=cur_name)
        ttk.Entry(f,textvariable=self.elig_name,width=50).grid(row=2,column=1,sticky="w")

        tk.Label(f,text="Semester",bg=WHITE,fg=MUTED).grid(row=3,column=0,sticky="w",pady=(12,0))
        self.elig_sem=tk.StringVar(value=SEMESTER_CHOICES[0])
        ttk.Combobox(f,textvariable=self.elig_sem,values=SEMESTER_CHOICES,state="readonly",width=22).grid(row=4,column=0,sticky="w",padx=(0,20))

        tk.Label(f,text="Course to check (Optional)",bg=WHITE,fg=MUTED).grid(row=5,column=0,columnspan=2,sticky="w",pady=(12,0))
        self.elig_course=tk.StringVar()
        ttk.Combobox(f,textvariable=self.elig_course,values=[f"{c.get('name','')} ({c.get('code','')})" for c in self.courses],width=60).grid(row=6,column=0,columnspan=2,sticky="w")

        btn_row=tk.Frame(f,bg=WHITE); btn_row.grid(row=7,column=0,columnspan=2,sticky="w", pady=(15,0))
        tk.Button(btn_row,text="Check Specific Course",bg=PURPLE,fg=WHITE,relief="flat",padx=16,pady=9,command=self.check_eligibility).pack(side="left",padx=(0,10))
        tk.Button(btn_row,text="Show All Eligible Courses",bg=TEAL,fg=WHITE,relief="flat",padx=16,pady=9,command=self.show_all_eligible).pack(side="left")

        self.elig_result=tk.Label(f,text="Enter your Student ID or your Name, then choose a course (or click 'Show All Eligible Courses').",bg=WHITE,fg=MUTED,justify="left",wraplength=820)
        self.elig_result.grid(row=8,column=0,columnspan=3,sticky="w",pady=(16,0))

    def _selected_semester(self):
        """Return (semester number or None, label) from the semester selector."""
        choice=self.elig_sem.get() if hasattr(self,"elig_sem") else SEMESTER_CHOICES[-1]
        if choice==SEMESTER_CHOICES[0]: return 1,"semester 1 (Fall)"
        if choice==SEMESTER_CHOICES[1]: return 2,"semester 2 (Spring)"
        return None,"all semesters"

    def _elig_error(self,text):
        self.elig_result.configure(text=text,fg="#B42318")

    def _verify_student(self):
        """Find the student by ID OR by name (one is enough). If both are given they must match."""
        sid=self.elig_sid.get().strip()
        name=self.elig_name.get().strip()
        if not sid and not name:
            self._elig_error("Please enter your Student ID or your Student Name.")
            return None

        by_id=None
        if sid:
            by_id=next((k for k in self.students if str(k).strip().upper()==sid.upper()),None)
            if by_id is None and not name:
                self._elig_error(f"Student ID '{sid}' was not found. Register your profile in the Dashboard first, or check the ID.")
                return None

        by_name=[]
        if name:
            by_name=[k for k,v in self.students.items() if _norm_name(v.get("name",""))==_norm_name(name)]
            if not by_name and not sid:
                self._elig_error(f"No student named '{name}' was found. Check the spelling or use your Student ID.")
                return None

        if sid and name:                      # both given -> they must agree
            if by_id is None:
                self._elig_error(f"Student ID '{sid}' was not found.")
                return None
            if by_id not in by_name:
                self._elig_error("The name you entered does not match this Student ID. Enter just one of them, or correct it.")
                return None
            key=by_id
        elif sid:
            key=by_id
        else:
            if len(by_name)>1:
                self._elig_error(f"{len(by_name)} students have this name. Please enter your Student ID instead.")
                return None
            key=by_name[0]

        st=self.students[key]
        self.elig_sid.set(key); self.elig_name.set(st.get("name",""))   # show the full record that was found
        self.hello.set_title(f"Hi, {st.get('name', 'Student')}")
        return key,st

    def show_all_eligible(self):
        verified=self._verify_student()
        if not verified: return
        sid,st=verified

        completed = [str(x).strip().upper() for x in st.get("completed", [])]
        course_by_code = {str(c.get("code", "")).strip().upper(): c for c in self.courses}
        passed_hours = self._student_hours(st)

        try:
            self.kb.load(self.courses, str(RULES))
            semester, sem_label = self._selected_semester()
            codes = self.kb.eligible_courses(completed, passed_hours, semester)
            cg = st.get("cgpa")
            max_hours = self.kb.get_max_allowed_hours(cg, not completed) if isinstance(cg, (int, float)) else None
            max_line = f" | Max Allowed Hours: {max_hours}" if max_hours is not None else ""
            def _credits(code):
                try: return float(course_by_code[code].get("credits", 0) or 0)
                except ValueError: return 0.0
            listed = [code for code in codes if code in course_by_code]
            total_credits = sum(_credits(code) for code in listed)
            formatted = [f"{code} ({course_by_code[code].get('name', '')}, {_credits(code):g} cr, level {course_by_code[code].get('level', '-')})" for code in listed]
            note = ""
            if max_hours is not None and total_credits > max_hours:
                note = f"\n\nNote: these courses add up to {total_credits:g} credit hours, but you can register for at most {max_hours} hours in a semester. Choose among them."
            msg = (
                f"Student: {st.get('name', sid)} ({sid}) | Passed Hours: {passed_hours:g}{max_line}\n"
                f"Eligible to register for {len(formatted)} course(s) in {sem_label} (total {total_credits:g} credit hours):\n\n"
                + (", ".join(formatted) if formatted else "None") + note
            )
            self.elig_result.configure(text=msg, fg="#16794B")
            storage.log_query(sid, f"which courses am I eligible to register for? ({sem_label})", f"{len(formatted)} eligible courses")
        except Exception as exc:
            messagebox.showerror("Eligibility check failed", f"Could not list eligible courses.\n{exc}")

    def check_eligibility(self):
        verified=self._verify_student()
        if not verified: return
        sid,st=verified

        selected = self.elig_course.get().strip()
        code = selected.rsplit("(", 1)[-1].rstrip(")") if "(" in selected else selected
        course = next((c for c in self.courses
                       if str(c.get("code", "")).strip().upper() == code.upper()
                       or str(c.get("name", "")).strip().lower() == selected.lower()), None)
        if not selected or not course:
            self._elig_error("Please choose a valid course to check.")
            return

        completed = [str(x).strip().upper() for x in st.get("completed", [])]
        passed_hours = self._student_hours(st)

        try:
            self.kb.load(self.courses, str(RULES))
            semester, sem_label = self._selected_semester()
            explanation = self.kb.why_not(completed, str(course.get("code", "")).strip().upper(), passed_hours, semester)
            cg = st.get("cgpa")
            max_line = ""
            if isinstance(cg, (int, float)):
                max_line = f"Max registration hours for CGPA {cg:g}: {self.kb.get_max_allowed_hours(cg, not completed)}\n"
            eligible = explanation.startswith("Course ") and " is available for registration." in explanation
            color = "#16794B" if eligible else "#B42318"
            result = "ELIGIBLE" if eligible else "NOT ELIGIBLE"
            msg = (
                f"Student: {st.get('name', sid)} ({sid})\n"
                f"Course: {course.get('name')} ({course.get('code')}) | Semester checked: {sem_label}\n"
                f"Completed credit hours from records: {passed_hours:g}\n"
                f"{max_line}Result: {result}\n\n{explanation}"
            )
            self.elig_result.configure(text=msg, fg=color)
            try:
                storage.log_query(sid, f"eligibility:{course.get('code')} ({sem_label})", result)
            except Exception:
                pass
        except Exception as exc:
            messagebox.showerror("Eligibility check failed", f"Could not check the course rules.\n{exc}")

    def _student_hours(self, st):
        """Completed hours = sum of the credits of the passed courses (single source of truth)."""
        credits={str(c.get("code","")).strip().upper(): c.get("credits","") for c in self.courses}
        total=0.0
        for code in st.get("completed", []):
            try: total+=float(credits.get(str(code).strip().upper(),0) or 0)
            except ValueError: pass
        return total

    # === Staff and Rooms (data files are dicts keyed by ID: T01.., R01..) ===
    def _scrollable(self):
        """Create a scrollable frame inside self.body and return the inner frame."""
        outer = tk.Frame(self.body, bg=BG); outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _wheel(e):
            canvas.yview_scroll(-1 if (e.num == 4 or e.delta > 0) else 1, "units")
        def _bind(_):
            canvas.bind_all("<MouseWheel>", _wheel); canvas.bind_all("<Button-4>", _wheel); canvas.bind_all("<Button-5>", _wheel)
        def _unbind(_):
            canvas.unbind_all("<MouseWheel>"); canvas.unbind_all("<Button-4>"); canvas.unbind_all("<Button-5>")
        canvas.bind("<Enter>", _bind); canvas.bind("<Leave>", _unbind)
        return inner

    def _info_card(self, parent, title, lines):
        f = tk.Frame(parent, bg=WHITE, highlightbackground=LINE, highlightthickness=1, padx=16, pady=12)
        f.pack(fill="x", pady=6, padx=(0, 10))
        tk.Label(f, text=title, font=("Segoe UI", 14, "bold"), bg=WHITE, fg=INK).pack(anchor="w")
        for line in lines:
            if line:
                tk.Label(f, text=line, font=("Segoe UI", 10), bg=WHITE, fg=MUTED, justify="left", wraplength=760).pack(anchor="w", pady=(3, 0))
        kit.accent_strip(f, TEAL); kit.card_hover(f, LINE, TEAL)

    @staticmethod
    def _display_name(rec):
        en = rec.get("name_en") or rec.get("name") or "Unknown"
        ar = rec.get("name_ar")
        return f"{en}  ({ar})" if ar else en

    def _staff_page(self):
        inner = self._scrollable()
        staff_data = read_records("staff.json")
        if not staff_data:
            tk.Label(inner, text="No staff members found.", bg=BG, fg=MUTED).pack(anchor="w", pady=10)
        course_names = {str(c.get("code", "")).strip().upper(): c.get("name", "") for c in self.courses}
        for st in staff_data:
            codes = st.get("courses") or []
            if isinstance(codes, str): codes = [x.strip() for x in codes.split(",") if x.strip()]
            courses_txt = ", ".join(f"{c} ({course_names[c.upper()]})" if c.upper() in course_names else c for c in codes)
            self._info_card(inner, self._display_name(st), [
                f"Staff ID: {st.get('id', '-')}   |   Department: {st.get('department', '-')}",
                f"Courses: {courses_txt}" if courses_txt else "",
                f"Office: {st.get('office', '-')}   |   Office Hours: {st.get('office_hours', '-')}",
                f"Email: {st.get('email')}" if st.get("email") else "",
            ])

    def _rooms_page(self):
        inner = self._scrollable()
        rooms_data = read_records("rooms.json")
        if not rooms_data:
            tk.Label(inner, text="No rooms found.", bg=BG, fg=MUTED).pack(anchor="w", pady=10)
        for rm in rooms_data:
            location = rm.get("location") or ", ".join(
                x for x in (rm.get("building"), f"Floor {rm['floor']}" if rm.get("floor") not in (None, "") else "") if x) or "-"
            self._info_card(inner, self._display_name(rm), [
                f"Room ID: {rm.get('id', '-')}   |   Location: {location}   |   Type: {rm.get('type', '-')}",
                f"Capacity: {rm.get('capacity', '-')} seats",
                f"Equipment: {rm.get('equipment')}" if rm.get("equipment") else "",
            ])

    def _faq_page(self):
        inner=self._scrollable()   # scrollable area (mouse wheel + scrollbar), same as Staff / Rooms pages
        items=[x for x in read_faqs() if isinstance(x,dict)]
        if not items:
            tk.Label(inner,text="No FAQs found in data/faqs.json",bg=BG,fg=MUTED).pack(anchor="w",pady=10)
            return
        for item in items:
            q=item.get("question",item.get("q","")); a=item.get("answer",item.get("a",""))
            card=tk.Frame(inner,bg=WHITE,highlightbackground=LINE,highlightthickness=1,padx=16,pady=12)
            card.pack(fill="x",pady=6,padx=(0,10))
            tk.Label(card,text="Q. "+str(q),bg=WHITE,fg=INK,font=("Segoe UI",11,"bold"),wraplength=760,justify="left").pack(anchor="w")
            tk.Label(card,text=str(a),bg=WHITE,fg=MUTED,font=("Segoe UI",10),wraplength=760,justify="left").pack(anchor="w",pady=(6,0))
            kit.accent_strip(card,PURPLE); kit.card_hover(card,LINE,PURPLE)

def main():
    ui=StudentUI(); ui.root.mainloop()
if __name__=="__main__": main()
