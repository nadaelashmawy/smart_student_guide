"""TechNova | Smart Student Guide - animated launcher (choose Student or Admin)."""
import math
import os
import random
import time
import tkinter as tk

import ui_kit as kit
from student import StudentUI
from admin_ui import AdminUI

ADMIN_PASSWORD = os.environ.get("SSG_ADMIN_PASSWORD", "admin123")

W, H = 920, 660
BG1, BG2 = "#0A0E2A", "#171D55"
CARD_BG, CARD_BG_HOVER, CARD_EDGE = "#131948", "#1B2368", "#2A3278"


def _bg_at(y):
    return kit.lerp_color(BG1, BG2, max(0.0, min(1.0, y / H)))


# ====================================================================== admin login dialog
class AdminLogin(tk.Toplevel):
    """Dark password dialog with a shake animation on a wrong password."""

    def __init__(self, parent, on_success):
        super().__init__(parent)
        self.on_success = on_success
        self.title("Admin Login")
        self.configure(bg=kit.SIDEBAR)
        self.resizable(False, False)
        self.transient(parent)
        w, h = 400, 440
        x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - h) // 2
        self.geometry(f"{w}x{h}+{max(0, x)}+{max(0, y)}")

        logo = tk.Canvas(self, width=w, height=120, bg=kit.SIDEBAR, highlightthickness=0)
        logo.pack(pady=(26, 0))
        kit.draw_logo_image(logo, w / 2, 62, 66)
        tk.Label(self, text="Admin Access", bg=kit.SIDEBAR, fg="#FFFFFF",
                 font=("Segoe UI", 18, "bold")).pack(pady=(4, 2))
        tk.Label(self, text="Enter the password to open the dashboard", bg=kit.SIDEBAR, fg="#8A92C4",
                 font=("Segoe UI", 10)).pack()

        self.box = tk.Frame(self, bg="#1B2257", highlightthickness=2, highlightbackground="#2A3278",
                            highlightcolor=kit.CYAN)
        self.box.pack(pady=(22, 6), padx=48, fill="x")
        self.entry = tk.Entry(self.box, show="•", relief="flat", bg="#1B2257", fg="#FFFFFF",
                              insertbackground="#FFFFFF", font=("Segoe UI", 14), justify="center", bd=0)
        self.entry.pack(fill="x", ipady=10, padx=8)
        self.entry.bind("<Return>", lambda e: self._submit())

        self.msg = tk.Label(self, text="", bg=kit.SIDEBAR, fg="#FF6B8B", font=("Segoe UI", 9, "bold"))
        self.msg.pack(pady=(0, 6))

        unlock = tk.Button(self, text="Unlock Dashboard", bg=kit.VIOLET, fg="#FFFFFF", relief="flat",
                           font=("Segoe UI", 11, "bold"), pady=10, command=self._submit)
        unlock.pack(padx=48, fill="x")
        kit.hover_button(unlock, kit.VIOLET, kit.lerp_color(kit.VIOLET, kit.CYAN, 0.35))
        cancel = tk.Button(self, text="Cancel", bg=kit.SIDEBAR, fg="#8A92C4", relief="flat",
                           font=("Segoe UI", 10), command=self.destroy)
        cancel.pack(pady=(8, 0))
        kit.hover_button(cancel, kit.SIDEBAR, kit.SIDEBAR_HOVER, "#8A92C4", "#FFFFFF")

        self.bind("<Escape>", lambda e: self.destroy())
        self.entry.focus_set()
        self.after(80, self._grab)

    def _grab(self):
        try:
            self.grab_set()
        except tk.TclError:
            pass

    def _submit(self):
        if self.entry.get() == ADMIN_PASSWORD:
            cb = self.on_success
            self.destroy()
            cb()
            return
        self.msg.configure(text="Incorrect password - try again")
        self.entry.delete(0, "end")
        self._shake()

    def _shake(self):
        x0, y0 = self.winfo_x(), self.winfo_y()

        def step(t):
            dx = int(math.sin(t * math.pi * 7) * (1 - t) * 16)
            self.geometry(f"+{x0 + dx}+{y0}")

        kit.tween(self, 420, step, lambda: self.geometry(f"+{x0}+{y0}"), easing=kit.linear)


# ====================================================================== launcher
class LauncherApp:
    """Animated launcher: TN logo, TechNova brand, Student / Admin cards."""

    def __init__(self, root):
        self.root = root
        root.title("TechNova | Smart Student Guide")
        root.configure(bg=BG1)
        root.resizable(False, False)
        kit.center_window(root, W, H)
        self.c = tk.Canvas(root, width=W, height=H, highlightthickness=0, bd=0, bg=BG1)
        self.c.pack()
        self.off, self.hov, self.tok = {}, {}, {}
        self.children = set()            # open Student / Admin / login windows
        self._moving_until = 0.0
        root.bind("<Configure>", self._on_root_configure, add="+")
        self._background()
        self._brand()
        self._cards()
        self._footer()
        self._reveal_all()
        self._tick_bg()
        kit.fade_in_window(root)

    # ------------------------------------------------------------ background
    def _background(self):
        c = self.c
        kit.draw_vgradient(c, W, H, BG1, BG2, tags="bg", step=4)
        for gx in range(30, W, 44):                      # subtle dot grid
            for gy in range(30, H, 44):
                c.create_rectangle(gx, gy, gx + 2, gy + 2, fill=kit.lerp_color(_bg_at(gy), "#FFFFFF", 0.07),
                                   width=0, tags="bg")
        self.orbs = []
        specs = [(140, 150, 230, kit.VIOLET, 0.45, 0.30), (790, 130, 200, kit.CYAN, -0.40, 0.34),
                 (720, 570, 260, kit.PINK, -0.30, -0.38), (110, 560, 190, "#3B82F6", 0.38, -0.28),
                 (460, 330, 150, kit.VIOLET, 0.22, 0.40)]
        for i, (x, y, r, col, vx, vy) in enumerate(specs):
            tag = f"orb{i}"
            for k, a in ((1.0, 0.035), (0.86, 0.05), (0.72, 0.065), (0.58, 0.08), (0.44, 0.10), (0.30, 0.12)):
                c.create_oval(x - r * k, y - r * k, x + r * k, y + r * k,
                              fill=kit.lerp_color(_bg_at(y), col, a), outline="", tags=("bg", tag))
            self.orbs.append([tag, x, y, vx, vy])
        self.dots = []
        rnd = random.Random(7)
        for _ in range(34):
            x, y, r = rnd.randint(0, W), rnd.randint(0, H), rnd.choice((1, 1, 2, 2, 3))
            it = c.create_oval(x - r, y - r, x + r, y + r,
                               fill=kit.lerp_color(_bg_at(y), "#FFFFFF", rnd.choice((0.18, 0.30, 0.45))),
                               outline="", tags="bg")
            self.dots.append([it, x, y, rnd.uniform(0.25, 0.8)])

    # The background animation is heavy (dozens of big overlapping canvas items). It shares the Tk event
    # loop with every other window, so while a child window is open (or being dragged) it must idle,
    # otherwise dragging those windows stutters.
    def _on_root_configure(self, e):
        if e.widget is self.root:
            self._moving_until = time.monotonic() + 0.25

    def _paused(self):
        if self.children or time.monotonic() < self._moving_until:
            return True
        try:
            return self.root.state() != "normal"
        except tk.TclError:
            return True

    def _track(self, win):
        self.children.add(win)

        def gone(e, w=win):
            if e.widget is w:
                self.children.discard(w)

        win.bind("<Destroy>", gone, add="+")

    def _tick_bg(self):
        if not kit._alive(self.c):
            return
        if self._paused():
            self.c.after(120, self._tick_bg)
            return
        for o in self.orbs:
            tag, x, y, vx, vy = o
            if x < -40 or x > W + 40:
                vx = -vx
            if y < -40 or y > H + 40:
                vy = -vy
            o[1], o[2], o[3], o[4] = x + vx, y + vy, vx, vy
            self.c.move(tag, vx, vy)
        for d in self.dots:
            d[2] -= d[3]
            self.c.move(d[0], 0, -d[3])
            if d[2] < -6:
                self.c.move(d[0], 0, H + 12)
                d[2] += H + 12
        self.c.after(33, self._tick_bg)

    # ------------------------------------------------------------ brand
    def _brand(self):
        c, cx = self.c, W / 2
        size, cy = 124, 86
        kit.pulse_ring(c, cx, cy, size, kit.CYAN, _bg_at(cy), paused=self._paused)
        # square TechNova logo image (pre-sized PNG, no Pillow needed)
        self.logo_img = tk.PhotoImage(file=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                        "assets", "technova_logo.png"))
        c.create_rectangle(cx - size / 2 - 2, cy - size / 2 - 2, cx + size / 2 + 2, cy + size / 2 + 2,
                           outline=kit.CYAN, width=1, tags="g_logo")
        c.create_image(cx, cy, image=self.logo_img, tags="g_logo")
        c.create_text(cx, 176, text="TechNova", font=("Segoe UI", 24, "bold"), fill="#FFFFFF", tags="g_name")
        c.create_text(cx, 210, text=kit.spaced("SMART STUDENT GUIDE"), font=("Segoe UI", 9, "bold"),
                      fill="#7FB6FF", tags="g_tag")
        c.create_text(cx, 290, text="Choose how you want to continue", font=("Segoe UI", 12),
                      fill="#8A92C4", tags="g_prompt")

    # ------------------------------------------------------------ cards
    def _cards(self):
        cw, ch, y0 = 330, 214, 338
        self._make_card("card_student", 110, y0, 110 + cw, y0 + ch, kit.CYAN, kit.VIOLET,
                        "Student Portal",
                        "Find courses, check your registration eligibility and search regulations.",
                        self._icon_cap, self.open_student, "Open Portal  →")
        self._make_card("card_admin", 480, y0, 480 + cw, y0 + ch, kit.PINK, kit.ORANGE,
                        "Admin Dashboard",
                        "Manage courses, students, FAQs and documents. Password protected.",
                        self._icon_shield, self.open_admin, "Admin Login  →")

    def _make_card(self, key, x0, y0, x1, y1, a1, a2, title, desc, icon_fn, cmd, cta):
        c = self.c
        kit.round_rect(c, x0 + 4, y0 + 14, x1 - 4, y1 + 12, r=24,
                       fill=kit.lerp_color(BG2, "#000000", 0.45), outline="", tags=("g_" + key,))
        body = kit.round_rect(c, x0, y0, x1, y1, r=24, fill=CARD_BG, outline=CARD_EDGE, width=1,
                              tags=("g_" + key, key))
        cx, cy = x0 + 58, y0 + 64
        c.create_oval(cx - 34, cy - 34, cx + 34, cy + 34, fill=kit.lerp_color(CARD_BG, a1, 0.22),
                      outline="", tags=("g_" + key, key))
        c.create_oval(cx - 28, cy - 28, cx + 28, cy + 28, fill=a1, outline="", tags=("g_" + key, key))
        icon_fn(cx, cy, a1, ("g_" + key, key))
        c.create_text(x0 + 110, y0 + 50, text=title, anchor="w", font=("Segoe UI", 18, "bold"),
                      fill="#FFFFFF", tags=("g_" + key, key))
        c.create_text(x0 + 110, y0 + 70, text=desc, anchor="nw", width=x1 - x0 - 130,
                      font=("Segoe UI", 10), fill="#9AA2D2", tags=("g_" + key, key))
        pill = kit.round_rect(c, x0 + 28, y1 - 66, x1 - 28, y1 - 26, r=20, fill=a1, outline="",
                              tags=("g_" + key, key))
        c.create_text((x0 + x1) / 2, y1 - 46, text=cta, font=("Segoe UI", 12, "bold"), fill="#FFFFFF",
                      tags=("g_" + key, key))
        self.off[key], self.hov[key] = 0.0, 0.0
        parts = dict(body=body, pill=pill, a1=a1, a2=a2)
        c.tag_bind(key, "<Enter>", lambda e, k=key, p=parts: self._hover(k, p, 1.0))
        c.tag_bind(key, "<Leave>", lambda e, k=key, p=parts: self._hover(k, p, 0.0))
        c.tag_bind(key, "<Button-1>", lambda e, f=cmd: f())

    def _hover(self, key, parts, target):
        self.c.configure(cursor="hand2" if target else "")
        token = object()
        self.tok[key] = token
        p0 = self.hov[key]

        def step(t):
            if self.tok.get(key) is not token:
                return
            p = p0 + (target - p0) * t
            self.hov[key] = p
            dy = -10 * p
            self.c.move(key, 0, dy - self.off[key])
            self.off[key] = dy
            self.c.itemconfigure(parts["body"], fill=kit.lerp_color(CARD_BG, CARD_BG_HOVER, p),
                                 outline=kit.lerp_color(CARD_EDGE, parts["a1"], p), width=1 + int(p * 1.5))
            self.c.itemconfigure(parts["pill"], fill=kit.lerp_color(parts["a1"], parts["a2"], p))

        kit.tween(self.c, 200, step)

    def _icon_cap(self, cx, cy, accent, tags):
        c = self.c
        c.create_polygon(cx - 20, cy - 4, cx, cy - 15, cx + 20, cy - 4, cx, cy + 6, fill="#FFFFFF",
                         outline="", tags=tags)
        c.create_polygon(cx - 11, cy + 1, cx - 11, cy + 10, cx, cy + 16, cx + 11, cy + 10, cx + 11, cy + 1,
                         cx, cy + 7, fill="#DCE4FF", outline="", tags=tags)
        c.create_line(cx + 20, cy - 4, cx + 20, cy + 9, fill="#FFFFFF", width=2, tags=tags)
        c.create_oval(cx + 17, cy + 8, cx + 23, cy + 14, fill="#FFFFFF", outline="", tags=tags)

    def _icon_shield(self, cx, cy, accent, tags):
        c = self.c
        c.create_polygon(cx, cy - 18, cx + 15, cy - 11, cx + 15, cy + 2, cx, cy + 18, cx - 15, cy + 2,
                         cx - 15, cy - 11, fill="#FFFFFF", outline="", tags=tags)
        c.create_line(cx - 7, cy - 1, cx - 2, cy + 5, cx + 8, cy - 7, fill=accent, width=3,
                      capstyle="round", joinstyle="round", tags=tags)

    # ------------------------------------------------------------ footer
    def _footer(self):
        c = self.c
        c.create_text(W / 2, H - 34, text="© 2026 TechNova  ·  Faculty of Artificial Intelligence",
                      font=("Segoe UI", 9), fill="#6E76A8", tags="g_footer")
        ex = c.create_text(W - 44, H - 34, text="✕  Exit", anchor="e", font=("Segoe UI", 10, "bold"),
                           fill="#8A92C4", tags=("g_footer", "exit"))

        def enter(_):
            c.configure(cursor="hand2")
            c.itemconfigure(ex, fill="#FFFFFF")

        def leave(_):
            c.configure(cursor="")
            c.itemconfigure(ex, fill="#8A92C4")

        c.tag_bind("exit", "<Enter>", enter)
        c.tag_bind("exit", "<Leave>", leave)
        c.tag_bind("exit", "<Button-1>", lambda e: self.root.destroy())

    # ------------------------------------------------------------ intro animation
    def _reveal_all(self):
        for tag, delay in [("g_logo", 150), ("g_name", 350), ("g_tag", 520), ("g_prompt", 700),
                           ("g_card_student", 850), ("g_card_admin", 1000), ("g_footer", 1250)]:
            self._reveal(tag, delay)

    def _reveal(self, tag, delay, dy=30, duration=650):
        c = self.c
        fin = {}
        for it in c.find_withtag(tag):
            for opt in ("fill", "outline"):
                try:
                    val = c.itemcget(it, opt)
                except tk.TclError:
                    continue
                if val and val.startswith("#"):
                    fin[(it, opt)] = val
                    c.itemconfigure(it, **{opt: _bg_at(c.coords(it)[1])})
        c.move(tag, 0, dy)

        def start():
            last = {"d": float(dy)}

            def step(t):
                d = dy * (1 - t)
                c.move(tag, 0, d - last["d"])
                last["d"] = d
                for (it, opt), val in fin.items():
                    try:
                        c.itemconfigure(it, **{opt: kit.lerp_color(_bg_at(c.coords(it)[1]), val, t)})
                    except (tk.TclError, IndexError):
                        pass

            kit.tween(c, duration, step)

        c.after(delay, start)

    # ------------------------------------------------------------ actions
    def open_student(self):
        win = tk.Toplevel(self.root)
        self._track(win)
        StudentUI(win)

    def open_admin(self):
        self._track(AdminLogin(self.root, self._open_admin_window))

    def _open_admin_window(self):
        win = tk.Toplevel(self.root)
        self._track(win)
        AdminUI(win)


def main():
    root = tk.Tk()
    LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
