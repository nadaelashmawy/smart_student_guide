import math
import re
from collections import Counter

STOP_WORDS_EN = {"a", "an", "the", "is", "are", "was", "were", "of", "to", "in", "on", "for", "and", "or", "what", "which", "who", "how", "do", "does", "i", "me", "my", "with", "at", "by", "from", "it", "this", "that", "be", "can", "many", "much", "would", "should", "could", "there", "about", "if", "when", "where", "i",}
STOP_WORDS_AR = {"في", "من", "على", "الى", "إلى", "عن", "ما", "ماذا", "هو", "هي", "ده", "دي", "ايه", "إيه", "هل", "كل", "مع", "او", "أو", "و", "ان", "إن", "اللي", "الي", "انا", "أنا", "لو", "يا",}
STOP_WORDS = STOP_WORDS_EN | STOP_WORDS_AR
_DIACRITICS = re.compile(r"[\u064B-\u0652\u0640]")
_ARABIC = re.compile(r"[\u0600-\u06FF]")
_AR_PREFIXES = ("وال", "بال", "كال", "فال", "ال")

def _stem(token: str) -> str:
    """Very light stemming so 'الغياب'/'غياب' and 'hours'/'hour' match."""
    if _ARABIC.search(token):
        token = token.replace("ى", "ي").replace("ة", "ه")
        for prefix in _AR_PREFIXES:
            if token.startswith(prefix) and len(token) - len(prefix) >= 3:
                token = token[len(prefix):]
                break
        if token.endswith("ات") and len(token) > 4:
            token = token[:-2]
        elif token.endswith("ه") and len(token) > 3:
            token = token[:-1]
        return token
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 3 and token.endswith("s") and not token.endswith(("ss", "us", "is")):
        return token[:-1]
    return token

# Common student phrasing -> words actually used in the regulation documents (query side only)
_RAW_SYNONYMS = {
    "مادة": ["مقرر"], "مواد": ["مقرر"], "كورس": ["مقرر"], "كورسات": ["مقرر"],
    "اسحب": ["منسحب", "انسحاب"], "سحب": ["منسحب", "انسحاب"], "انسحب": ["منسحب", "انسحاب"],
    "ارسب": ["رسوب"], "رسب": ["رسوب"], "اجل": ["انقطاع"], "تاجيل": ["انقطاع"],
    "معدل": ["cgpa"], "تراكمي": ["cgpa"], "gpa": ["cgpa"], "grade": ["تقدير"],
}
QUERY_SYNONYMS = {_stem(k): v for k, v in _RAW_SYNONYMS.items()}

class SearchEngine:
    def __init__(self) -> None:
        self.index: dict[str, dict[str, int]] = {}
        self.idf: dict[str, float] = {}
        self.doc_norms: dict[str, float] = {}
        self.num_docs: int = 0

    @staticmethod
    def preprocess(text: str) -> list[str]:
        text = text.lower()
        text = _DIACRITICS.sub("", text)
        text = re.sub(r"[أإآ]", "ا", text)
        tokens = re.findall(r"\w+", text)
        return [_stem(t) for t in tokens if t not in STOP_WORDS]

    def build_index(self, documents: dict[str, str]) -> None:
        self.index = {}
        self.idf = {}
        self.doc_norms = {}
        self.num_docs = len(documents)
        for doc_id, text in documents.items():
            counts = Counter(self.preprocess(text))
            for term, tf in counts.items():
                self.index.setdefault(term, {})[doc_id] = tf
        for term, postings in self.index.items():
            df = len(postings)
            self.idf[term] = math.log10(1 + self.num_docs / df)
        squares = dict.fromkeys(documents, 0.0)
        for term, postings in self.index.items():
            for doc_id, tf in postings.items():
                w = tf * self.idf[term]
                squares[doc_id] += w * w
        self.doc_norms = {d: math.sqrt(s) for d, s in squares.items()}

    def search(self, query: str, top_k: int = 5) -> list[tuple[str, float]]:
        q_tokens = self.preprocess(query)
        for token in list(q_tokens):
            q_tokens.extend(_stem(x) for x in QUERY_SYNONYMS.get(token, []))
        q_counts = Counter(q_tokens)
        q_weights = {t: tf * self.idf[t] for t, tf in q_counts.items() if t in self.idf}
        if not q_weights: return []
        q_norm = math.sqrt(sum(w * w for w in q_weights.values()))
        dots: dict[str, float] = {}
        for term, q_w in q_weights.items():
            for doc_id, tf in self.index[term].items():
                d_w = tf * self.idf[term]
                dots[doc_id] = dots.get(doc_id, 0.0) + q_w * d_w
        results = []
        for doc_id, dot in dots.items():
            denom = q_norm * self.doc_norms[doc_id]
            if denom > 0: results.append((doc_id, dot / denom))
        results.sort(key=lambda pair: pair[1], reverse=True)
        return results[:top_k]
