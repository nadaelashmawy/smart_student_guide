"""Modern dashboard-style Admin UI for Smart Student Guide (Tkinter)."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import json, csv, shutil
import storage
import ui_kit as kit

BASE=Path(__file__).resolve().parent
DATA=BASE/"data"; COURSES=DATA/"courses.csv"; FAQ=DATA/"faqs.json"; DOCS=DATA/"documents"
BG="#F3F5FB"; NAV="#F0F0F8"; WHITE="#FFFFFF"; INK="#1B1F3B"; MUTED="#6B7194"; PURPLE="#6C5CE7"; TEAL="#00B8A9"; LINE="#E3E6F3"
FIELDS=["code","name","credits","prerequisites","level","semester"]
LEVELS=["1","2","3","4"]; SEMESTERS=["1","2"]
SUBS={"Dashboard":"Overview of everything you manage","Manage Courses":"Add and update the course catalog","Students":"Top students and quick search","Manage FAQs":"Keep common answers up to date","Documents":"Regulation files used by the search engine","Activity Log":"Latest student queries"}

def load_students():
    d=storage.read_json(str(DATA/"students.json"))
    return d if isinstance(d,dict) else {}
def top_students(students, n=3):
    ranked=[(sid,st) for sid,st in students.items() if isinstance(st.get("cgpa"),(int,float))]
    ranked.sort(key=lambda kv:(-kv[1]["cgpa"],-len(kv[1].get("completed",[])),kv[0]))
    return ranked[:n]
def search_students(students, query, limit=100):
    q=" ".join(str(query).split()).lower()
    if not q: return []
    exact,part=[],[]
    for sid,st in students.items():
        if sid.lower()==q: exact.append((sid,st))
        elif q in sid.lower() or q in str(st.get("name","")).lower(): part.append((sid,st))
    return (exact+part)[:limit]

def load_courses(): return storage.read_csv(str(COURSES))
def load_faqs():
    x=storage.read_json(str(FAQ))
    return x if isinstance(x,list) else (x.get("faqs",[]) if isinstance(x,dict) else [])

class AdminUI:
    def __init__(self,root=None):
        self.root=root or tk.Tk(); self.root.title("Smart Student Guide | Admin Dashboard")
        self.root.geometry("1180x760"); self.root.minsize(980,650); self.root.configure(bg=BG)
        self._style(); self._layout(); self.show_page("Dashboard")
        if isinstance(self.root,tk.Tk): kit.fade_in_window(self.root)   # -alpha on a Toplevel makes dragging laggy on Windows
    def _style(self):
        st=ttk.Style()
        try: st.theme_use("clam")
        except tk.TclError: pass
        kit.style_ttk(st,WHITE,INK,LINE,PURPLE,BG,MUTED)
    def _layout(self):
        shell=tk.Frame(self.root,bg=BG); shell.pack(fill="both",expand=True)
        side=tk.Frame(shell,bg=kit.SIDEBAR,width=240); side.pack(side="left",fill="y"); side.pack_propagate(False)
        kit.brand_block(side).pack(anchor="w",padx=20,pady=(26,28))
        tk.Label(side,text="MENU",bg=kit.SIDEBAR,fg="#5F679F",font=("Segoe UI",8,"bold")).pack(anchor="w",padx=24,pady=(0,8))
        self.nav={}
        for name,icon in [("Dashboard","\u2302"),("Manage Courses","\u25A6"),("Students","\u263A"),("Manage FAQs","?"),("Documents","\u25A4"),("Activity Log","\u2261")]:
            b=kit.NavButton(side,f"  {icon}    {name}",lambda n=name:self.show_page(n),accent=kit.PINK)
            b.pack(fill="x",padx=(0,14),pady=2); self.nav[name]=b
        tk.Label(side,text="\u00a9 2026 TechNova",bg=kit.SIDEBAR,fg="#5F679F",font=("Segoe UI",8)).pack(side="bottom",anchor="w",padx=24,pady=(0,18))
        tk.Label(side,text="ADMIN WORKSPACE",bg=kit.SIDEBAR,fg="#8A92C4",font=("Segoe UI",8,"bold")).pack(side="bottom",anchor="w",padx=24,pady=(0,4))
        tk.Frame(side,bg="#1F2760",height=1).pack(side="bottom",fill="x",padx=20,pady=(0,12))
        main=tk.Frame(shell,bg=BG); main.pack(side="left",fill="both",expand=True)
        self.heading=kit.Banner(main,"Admin dashboard","Overview of everything you manage","SYSTEM MANAGEMENT",kit.PINK,kit.VIOLET)
        self.heading.pack(fill="x")
        self.body=tk.Frame(main,bg=BG); self.body.pack(fill="both",expand=True,padx=30,pady=(20,14))
    def show_page(self,name):
        for n,b in self.nav.items(): b.set_active(n==name)
        self.heading.set_title(name); self.heading.set_sub(SUBS.get(name,""))
        for w in self.body.winfo_children(): w.destroy()
        if name=="Dashboard": self.dashboard()
        elif name=="Manage Courses": self.courses_page()
        elif name=="Students": self.students_page()
        elif name=="Manage FAQs": self.faq_page()
        elif name=="Documents": self.docs_page()
        elif name=="Activity Log": self.logs_page()
        kit.finish_page(self.body,BG,self.heading)   # button hover + slide/fade-in
    def card(self,parent,title,value,sub,color):
        return kit.stat_card(parent,title,value,sub,color)
    def dashboard(self):
        tk.Label(self.body,text="Welcome back, Admin",bg=BG,fg=INK,font=("Segoe UI",19,"bold")).pack(anchor="w")
        tk.Label(self.body,text="Manage academic information from one simple workspace.",bg=BG,fg=MUTED).pack(anchor="w",pady=(4,18))
        docs=list(DOCS.glob("*.txt")) if DOCS.exists() else []
        stats=[("Total courses",len(load_courses()),"Course records",PURPLE),("Total students",len(load_students()),"Student records",TEAL),("Total FAQs",len(load_faqs()),"Quick answers","#F59E0B"),("Documents",len(docs),"Regulation files","#F43F8E")]
        row=tk.Frame(self.body,bg=BG); row.pack(fill="x",pady=(0,18))
        for t,v,s,c in stats:self.card(row,t,str(v),s,c).pack(side="left",fill="x",expand=True,padx=(0,10))
        tk.Label(self.body,text="Quick actions",bg=BG,fg=INK,font=("Segoe UI",13,"bold")).pack(anchor="w",pady=(2,10))
        row2=tk.Frame(self.body,bg=BG); row2.pack(fill="x")
        for title,desc,btn,page,col in [
            ("Course catalog","Add or update course information.","Manage courses","Manage Courses",PURPLE),
            ("FAQs","Maintain common questions and answers.","Edit FAQs","Manage FAQs",TEAL),
            ("Regulation documents","Add a text file to the document library.","Manage documents","Documents","#F59E0B")]:
            f=tk.Frame(row2,bg=WHITE,highlightbackground=LINE,highlightthickness=1,padx=16,pady=18);f.pack(side="left",fill="both",expand=True,padx=(0,10))
            tk.Label(f,text="●",bg=WHITE,fg=col,font=("Segoe UI",18)).pack(anchor="w")
            tk.Label(f,text=title,bg=WHITE,fg=INK,font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(7,4))
            tk.Label(f,text=desc,bg=WHITE,fg=MUTED,wraplength=190,justify="left").pack(anchor="w")
            tk.Button(f,text=btn,bg="#F0EFFD",fg=PURPLE,relief="flat",padx=12,pady=8,command=lambda p=page:self.show_page(p)).pack(anchor="w",pady=(13,0))
            kit.accent_strip(f,col); kit.card_hover(f,LINE,col)
    def courses_page(self):
        tk.Label(self.body,text="Manage the course catalog",bg=BG,fg=MUTED).pack(anchor="w",pady=(0,10))
        form=tk.Frame(self.body,bg=WHITE,padx=14,pady=12,highlightbackground=LINE,highlightthickness=1);form.pack(fill="x",pady=(0,12))
        self.vars={k:tk.StringVar() for k in FIELDS}
        labels=[("code","Course code"),("name","Course name"),("credits","Credit hours"),("prerequisites","Prerequisites (separate with ;)"),("level","Level (1-4)"),("semester","Semester (1 = Fall, 2 = Spring)")]
        for i,(key,label) in enumerate(labels):
            r,c=(i//4)*2,i%4
            tk.Label(form,text=label,bg=WHITE,fg=MUTED).grid(row=r,column=c,sticky="w",padx=(0,10),pady=(8 if r else 0,0))
            if key=="level": w=ttk.Combobox(form,textvariable=self.vars[key],values=LEVELS,state="readonly",width=22)
            elif key=="semester": w=ttk.Combobox(form,textvariable=self.vars[key],values=SEMESTERS,state="readonly",width=22)
            else: w=ttk.Entry(form,textvariable=self.vars[key],width=24)
            w.grid(row=r+1,column=c,sticky="ew",padx=(0,10))
        buttons=tk.Frame(form,bg=WHITE);buttons.grid(row=4,column=0,columnspan=4,sticky="w",pady=(12,0))
        tk.Button(buttons,text="Add course",bg=PURPLE,fg=WHITE,relief="flat",padx=14,pady=8,command=self.add_course).pack(side="left",padx=(0,8))
        tk.Button(buttons,text="Update selected",bg=TEAL,fg=WHITE,relief="flat",padx=14,pady=8,command=self.update_course).pack(side="left",padx=(0,8))
        tk.Button(buttons,text="Clear fields",bg="#ECECF6",fg=INK,relief="flat",padx=14,pady=8,command=self.clear_course).pack(side="left")
        box=tk.Frame(self.body,bg=WHITE,padx=10,pady=10);box.pack(fill="both",expand=True)
        self.course_tree=ttk.Treeview(box,columns=FIELDS,show="headings")
        for c,title,w in [("code","Code",100),("name","Course name",280),("credits","Credits",70),("prerequisites","Prerequisites",200),("level","Level",60),("semester","Semester",80)]:
            self.course_tree.heading(c,text=title,anchor="w");self.course_tree.column(c,width=w,anchor="w")
        self.course_tree.pack(fill="both",expand=True);self.course_tree.bind("<<TreeviewSelect>>",self.select_course);self.refresh_courses()
    def refresh_courses(self):
        rows=load_courses(); self.course_tree.delete(*self.course_tree.get_children())
        for r in rows:self.course_tree.insert("","end",values=tuple(r.get(k,"") for k in FIELDS))
    def clear_course(self):
        for v in self.vars.values():v.set("")
    def select_course(self,event=None):
        sel=self.course_tree.selection()
        if not sel:return
        vals=self.course_tree.item(sel[0],"values")
        for k,v in zip(FIELDS,vals):self.vars[k].set(v)
    def save_course_rows(self,rows):
        DATA.mkdir(parents=True, exist_ok=True)
        cols=list(FIELDS)
        for r in rows:
            for k in r:
                if k not in cols: cols.append(k)
        storage.write_csv(str(COURSES), [{k:r.get(k,"") for k in cols} for r in rows], cols)
    @staticmethod
    def _check_level_semester(d):
        """Level must be 1-4 and semester 1 or 2 (the eligibility check filters by semester)."""
        if d["level"] not in LEVELS:
            messagebox.showerror("Invalid level","Choose a level from 1 to 4.");return False
        if d["semester"] not in SEMESTERS:
            messagebox.showerror("Invalid semester","Choose semester 1 (Fall) or 2 (Spring).");return False
        return True
    def add_course(self):
        d={k:v.get().strip() for k,v in self.vars.items()}
        if not d["code"] or not d["name"] or not d["credits"]:
            messagebox.showwarning("Missing information","Enter course code, name, and credit hours.");return
        if not self._check_level_semester(d):return
        rows=load_courses()
        if any(r.get("code","").strip().lower()==d["code"].lower() for r in rows):
            messagebox.showerror("Duplicate code","This course code already exists. Select it to update instead.");return
        try:float(d["credits"])
        except ValueError:messagebox.showerror("Invalid credits","Credit hours must be a number.");return
        rows.append(d);self.save_course_rows(rows);self.refresh_courses();messagebox.showinfo("Saved","Course added successfully.");self.clear_course()
    def update_course(self):
        sel=self.course_tree.selection()
        if not sel:messagebox.showwarning("Select course","Select a course in the table first.");return
        old=self.course_tree.item(sel[0],"values")[0];d={k:v.get().strip() for k,v in self.vars.items()}
        if not d["code"] or not d["name"] or not d["credits"]:messagebox.showwarning("Missing information","Complete required fields.");return
        if not self._check_level_semester(d):return
        rows=load_courses()
        if any(r.get("code","").strip().lower()==d["code"].lower() and r.get("code","")!=old for r in rows):
            messagebox.showerror("Duplicate code","Another course already uses this code.");return
        try: float(d["credits"])
        except ValueError: messagebox.showerror("Invalid credits","Credit hours must be a number.");return
        for r in rows:
            if r.get("code","")==old:r.update(d)
        self.save_course_rows(rows);self.refresh_courses();messagebox.showinfo("Saved","Course updated successfully.")
    def students_page(self):
        self.students=load_students()
        tk.Label(self.body,text=f"Top 3 students by CGPA  (search to find any of the {len(self.students)} students)",bg=BG,fg=INK,font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(0,8))
        top=tk.Frame(self.body,bg=BG);top.pack(fill="x",pady=(0,14))
        for i,(sid,st) in enumerate(top_students(self.students,3),1):
            f=tk.Frame(top,bg=WHITE,highlightbackground=LINE,highlightthickness=1,padx=16,pady=12);f.pack(side="left",fill="x",expand=True,padx=(0,10))
            tk.Label(f,text=f"#{i}  •  CGPA {st['cgpa']:g}",bg=WHITE,fg=[PURPLE,TEAL,"#F59E0B"][i-1],font=("Segoe UI",12,"bold")).pack(anchor="w")
            tk.Label(f,text=st.get("name") or "(no name)",bg=WHITE,fg=INK,font=("Segoe UI",10,"bold")).pack(anchor="w",pady=(5,0))
            tk.Label(f,text=f"ID: {sid}  •  Level {st.get('level','-')}  •  Passed: {len(st.get('completed',[]))}",bg=WHITE,fg=MUTED,font=("Segoe UI",9)).pack(anchor="w")
            kit.accent_strip(f,[PURPLE,TEAL,"#F59E0B"][i-1]); kit.card_hover(f,LINE,[PURPLE,TEAL,"#F59E0B"][i-1])
        bar=tk.Frame(self.body,bg=WHITE,padx=14,pady=12);bar.pack(fill="x",pady=(0,10))
        self.stu_q=tk.StringVar()
        ent=ttk.Entry(bar,textvariable=self.stu_q);ent.pack(side="left",fill="x",expand=True,padx=(0,10))
        ent.bind("<Return>",lambda e:self.search_students_ui());ent.bind("<KeyRelease>",lambda e:self.search_students_ui())
        tk.Button(bar,text="Search by name or ID",bg=PURPLE,fg=WHITE,relief="flat",padx=16,pady=8,command=self.search_students_ui).pack(side="left")
        box=tk.Frame(self.body,bg=WHITE,padx=10,pady=10);box.pack(fill="both",expand=True)
        cols=("id","name","level","cgpa","passed")
        self.stu_tree=ttk.Treeview(box,columns=cols,show="headings")
        for c,t,w in [("id","Student ID",110),("name","Name",360),("level","Level",70),("cgpa","CGPA",80),("passed","Passed courses",120)]:
            self.stu_tree.heading(c,text=t,anchor="w");self.stu_tree.column(c,width=w,anchor="w")
        sb=ttk.Scrollbar(box,orient="vertical",command=self.stu_tree.yview);self.stu_tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right",fill="y");self.stu_tree.pack(fill="both",expand=True)
        self.stu_hint=tk.Label(self.body,text="Type a name or student ID to see matching students.",bg=BG,fg=MUTED);self.stu_hint.pack(anchor="w",pady=(6,0))
    def search_students_ui(self):
        res=search_students(self.students,self.stu_q.get())
        self.stu_tree.delete(*self.stu_tree.get_children())
        for sid,st in res:
            cg=st.get("cgpa")
            self.stu_tree.insert("","end",values=(sid,st.get("name") or "(no name)",st.get("level","-"),f"{cg:g}" if isinstance(cg,(int,float)) else "-",len(st.get("completed",[]))))
        self.stu_hint.configure(text=(f"{len(res)} result(s) shown (max 100)." if res else ("No student found." if self.stu_q.get().strip() else "Type a name or student ID to see matching students.")))

    # === FIX 1: FAQs Edit Capability ===
    def faq_page(self):
        self.faqs_data = load_faqs()
        f=tk.Frame(self.body,bg=WHITE,padx=16,pady=14);f.pack(fill="x",pady=(0,12))
        
        tk.Label(f,text="Select FAQ to edit:",bg=WHITE,fg=INK,font=("Segoe UI",10,"bold")).grid(row=0,column=0,sticky="w",pady=(0,5))
        self.faq_combo = ttk.Combobox(f, width=80, state="readonly")
        self.faq_combo.grid(row=1, column=0, columnspan=2, sticky="w", pady=(0,10))
        self.faq_combo.bind("<<ComboboxSelected>>", self.load_faq_for_edit)
        self.update_faq_combo()

        tk.Label(f,text="Question",bg=WHITE,fg=MUTED).grid(row=2,column=0,sticky="w")
        self.q=tk.StringVar();ttk.Entry(f,textvariable=self.q,width=52).grid(row=3,column=0,sticky="ew",padx=(0,12))
        tk.Label(f,text="Answer",bg=WHITE,fg=MUTED).grid(row=2,column=1,sticky="w")
        self.ans=tk.StringVar();ttk.Entry(f,textvariable=self.ans,width=52).grid(row=3,column=1,sticky="ew")
        
        btn_f = tk.Frame(f, bg=WHITE)
        btn_f.grid(row=4,column=0,columnspan=2,sticky="w",pady=(12,0))
        tk.Button(btn_f,text="Add New FAQ",bg=PURPLE,fg=WHITE,relief="flat",padx=16,pady=8,command=self.add_faq).pack(side="left", padx=(0,10))
        tk.Button(btn_f,text="Update Selected",bg=TEAL,fg=WHITE,relief="flat",padx=16,pady=8,command=self.update_faq).pack(side="left", padx=(0,10))
        tk.Button(btn_f,text="Clear",bg="#ECECF6",fg=INK,relief="flat",padx=16,pady=8,command=self.clear_faq_fields).pack(side="left")

        self.faq_box=tk.Listbox(self.body,bg=WHITE,fg=INK,relief="flat",font=("Segoe UI",10),height=12)
        self.faq_box.pack(fill="both",expand=True);self.refresh_faqs()

    def update_faq_combo(self):
        titles = [f"ID {x.get('id','-')}: {x.get('question',x.get('q',''))}" for x in self.faqs_data if isinstance(x,dict)]
        self.faq_combo['values'] = titles

    def load_faq_for_edit(self, event=None):
        idx = self.faq_combo.current()
        if idx >= 0 and idx < len(self.faqs_data):
            item = self.faqs_data[idx]
            self.q.set(item.get("question", item.get("q", "")))
            self.ans.set(item.get("answer", item.get("a", "")))

    def clear_faq_fields(self):
        self.q.set("")
        self.ans.set("")
        self.faq_combo.set("")

    def refresh_faqs(self):
        self.faq_box.delete(0,"end")
        for x in self.faqs_data:
            if isinstance(x,dict):self.faq_box.insert("end",x.get("question",x.get("q","")))

    def add_faq(self):
        q=self.q.get().strip();a=self.ans.get().strip()
        if not q or not a:messagebox.showwarning("Missing information","Enter both a question and an answer.");return
        ids=[x.get("id",0) for x in self.faqs_data if isinstance(x,dict) and isinstance(x.get("id"),int)]
        self.faqs_data.append({"id":max(ids,default=0)+1,"question":q,"answer":a})
        storage.write_json(str(FAQ),self.faqs_data);self.refresh_faqs();self.update_faq_combo();self.clear_faq_fields();messagebox.showinfo("Saved","FAQ added successfully.")

    def update_faq(self):
        idx = self.faq_combo.current()
        if idx < 0:
            messagebox.showwarning("Select FAQ", "Please select an FAQ to update from the dropdown list.")
            return
        q=self.q.get().strip();a=self.ans.get().strip()
        if not q or not a:messagebox.showwarning("Missing information","Enter both a question and an answer.");return
        
        self.faqs_data[idx]["question"] = q
        self.faqs_data[idx]["answer"] = a
        if "q" in self.faqs_data[idx]: del self.faqs_data[idx]["q"]
        if "a" in self.faqs_data[idx]: del self.faqs_data[idx]["a"]
        
        storage.write_json(str(FAQ),self.faqs_data)
        self.refresh_faqs();self.update_faq_combo();self.clear_faq_fields();
        messagebox.showinfo("Saved", "FAQ updated successfully.")

    # === FIX 2: Document Edit Capability ===
    def docs_page(self):
        f=tk.Frame(self.body,bg=WHITE,padx=16,pady=16);f.pack(fill="x",pady=(0,12))
        tk.Label(f,text="Manage Regulation Documents (TXT)",bg=WHITE,fg=INK,font=("Segoe UI",12,"bold")).pack(anchor="w",pady=(0,8))
        
        top_f = tk.Frame(f, bg=WHITE)
        top_f.pack(fill="x", pady=(0, 10))
        tk.Button(top_f,text="Upload new TXT file",bg=PURPLE,fg=WHITE,relief="flat",padx=14,pady=9,command=self.add_doc).pack(side="left", padx=(0, 20))
        
        tk.Label(top_f, text="Or edit existing:", bg=WHITE, fg=MUTED).pack(side="left", padx=(0, 5))
        self.doc_combo = ttk.Combobox(top_f, width=30, state="readonly")
        self.doc_combo.pack(side="left")
        self.doc_combo.bind("<<ComboboxSelected>>", self.load_doc_content)

        self.doc_content_text = tk.Text(f, height=10, bg=BG, fg=INK, font=("Consolas", 10), relief="flat")
        self.doc_content_text.pack(fill="both", expand=True, pady=10)

        tk.Button(f, text="Save Changes", bg=TEAL, fg=WHITE, relief="flat", padx=14, pady=9, command=self.save_doc_content).pack(anchor="w")

        self.docs_list=tk.Listbox(self.body,bg=WHITE,fg=INK,relief="flat",font=("Segoe UI",10));self.docs_list.pack(fill="both",expand=True);self.refresh_docs()

    def refresh_docs(self):
        self.docs_list.delete(0,"end")
        DOCS.mkdir(parents=True,exist_ok=True)
        files = [p.name for p in sorted(DOCS.glob("*.txt"))]
        for name in files: self.docs_list.insert("end",name)
        self.doc_combo['values'] = files

    def add_doc(self):
        p=filedialog.askopenfilename(title="Select a text document",filetypes=[("Text files","*.txt")])
        if not p:return
        DOCS.mkdir(parents=True,exist_ok=True);dest=DOCS/Path(p).name
        if dest.exists() and not messagebox.askyesno("Replace file?","A document with this name exists. Replace it?"):return
        shutil.copy2(p,dest);self.refresh_docs();messagebox.showinfo("Added","Document added to the library.")

    def load_doc_content(self, event=None):
        filename = self.doc_combo.get()
        if not filename: return
        filepath = DOCS / filename
        if filepath.exists():
            content = storage.read_text(str(filepath))
            self.doc_content_text.delete("1.0", "end")
            self.doc_content_text.insert("end", content)
    
    def save_doc_content(self):
        filename = self.doc_combo.get()
        if not filename:
            messagebox.showwarning("Warning", "Select a document to edit from the dropdown first.")
            return
        filepath = DOCS / filename
        content = self.doc_content_text.get("1.0", "end").strip()
        storage.write_text(str(filepath), content)
        messagebox.showinfo("Saved", f"{filename} saved successfully.")

    def logs_page(self):
        top=tk.Frame(self.body,bg=BG);top.pack(fill="x",pady=(0,8))
        tk.Button(top,text="Refresh",bg=PURPLE,fg=WHITE,relief="flat",padx=14,pady=7,command=lambda:self.show_page("Activity Log")).pack(side="left")
        box=tk.Frame(self.body,bg=WHITE,padx=12,pady=12);box.pack(fill="both",expand=True)
        sb=ttk.Scrollbar(box,orient="vertical");sb.pack(side="right",fill="y")
        t=tk.Text(box,wrap="word",bg=WHITE,fg=INK,relief="flat",font=("Consolas",10),yscrollcommand=sb.set);t.pack(side="left",fill="both",expand=True)
        sb.configure(command=t.yview)
        log=BASE/"logs"/"queries.log"
        content=log.read_text(encoding="utf-8") if log.exists() else ""
        if content.strip():
            t.insert("end",content);t.see("end")   # newest entries at the bottom
        else:
            t.insert("end","No activity has been logged yet.")
        t.configure(state="disabled")
