"""
storage.py - File handling and logging for the Smart Student Guide project.
Owner: Omar (role C).

Everything that touches files goes through this module:
  * CSV  -> course table
  * JSON -> students, FAQs, rules
  * TXT  -> regulation / description documents (used by the IR engine)
  * LOG  -> every user query (logs/queries.log)
"""

import csv
import datetime
import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DOCS_DIR = os.path.join(DATA_DIR, "documents")
LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "queries.log")

def _warn(message):
    print(f"[storage] WARNING: {message}")

def _ensure_parent_folder(path):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)

def read_text(path):
    try:
        with open(path, mode="r", encoding="utf-8-sig") as f:
            return f.read()
    except FileNotFoundError:
        _warn(f"text file not found: {path}")
        return ""

def write_text(path, text):
    _ensure_parent_folder(path)
    with open(path, mode="w", encoding="utf-8") as f:
        f.write(text)

def load_documents(folder=DOCS_DIR):
    documents = {}
    if not os.path.isdir(folder):
        _warn(f"documents folder not found: {folder}")
        return documents
    for file_name in sorted(os.listdir(folder)):
        if file_name.lower().endswith(".txt"):
            doc_id = os.path.splitext(file_name)[0]
            documents[doc_id] = read_text(os.path.join(folder, file_name))
    return documents

def read_csv(path):
    rows = []
    try:
        with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                clean = {key.strip(): (value or "").strip()
                         for key, value in row.items() if key is not None}
                if any(clean.values()):
                    rows.append(clean)
    except FileNotFoundError:
        _warn(f"CSV file not found: {path}")
    return rows

def write_csv(path, rows, fieldnames):
    _ensure_parent_folder(path)
    with open(path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

def split_prerequisites(value):
    return [item.strip() for item in (value or "").split(";") if item.strip()]

def read_json(path, default=None):
    if default is None:
        default = {}
    try:
        with open(path, mode="r", encoding="utf-8-sig") as f:
            return json.load(f)
    except FileNotFoundError:
        _warn(f"JSON file not found: {path}")
    except json.JSONDecodeError as error:
        _warn(f"JSON file is broken: {path} ({error})")
    return default

def write_json(path, data):
    _ensure_parent_folder(path)
    with open(path, mode="w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def log_query(student_id, query, result_summary):
    _ensure_parent_folder(LOG_FILE)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean_query = " ".join(str(query).split())
    line = f'{timestamp} | {student_id} | query: "{clean_query}" | results: {result_summary}\n'
    with open(LOG_FILE, mode="a", encoding="utf-8") as f:
        f.write(line)
